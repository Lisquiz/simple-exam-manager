<?php
/**
 * ExamCraft Uninstall
 * Removes all plugin data when deleted via WordPress admin.
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}ec_results");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}ec_questions");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}ec_exams");

delete_option('ec_db_ver');
