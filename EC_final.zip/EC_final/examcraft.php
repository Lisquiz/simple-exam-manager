<?php
/**
 * Plugin Name: ExamCraft
 * Description: Complete online exam platform v3 with Dark Mode, Scheduled Publishing, Student Reports, Spaced Repetition, Performance Analytics, Bookmarks, Notes, Countdown Timers, Schedule Management, Short Notes PDFs, Skeleton Loaders, Server-side Auto-save, Question Difficulty Tagging, Multi-category & Multi-tag support, Schedule-based access.
 * Version:     3.1.0
 * Author:      ExamCraft
 * Text Domain: examcraft
 * License:     GPLv2
 */
defined('ABSPATH') || exit;

define('EC_VER', '3.1.0');
define('EC_DIR', plugin_dir_path(__FILE__));
define('EC_URL', plugin_dir_url(__FILE__));

/* ══ SECURITY HELPERS ══ */
function ec_nonce($action='ec_nonce'){wp_nonce_field($action,'ec_nonce_field');}
function ec_verify_nonce($action='ec_nonce'){if(!isset($_REQUEST['ec_nonce_field'])||!wp_verify_nonce($_REQUEST['ec_nonce_field'],$action))wp_die('Security check failed.');}
function ec_verify_url_nonce(){if(!isset($_GET['_wpnonce'])||!wp_verify_nonce($_GET['_wpnonce'],'ec_nonce'))wp_die('Security check failed.');}
function ec_require_admin(){if(!current_user_can('manage_options'))wp_die('No permission.');}

/* ══ DATABASE v3.1 ══ */
function ec_install(){
    global $wpdb; $c=$wpdb->get_charset_collate();
    require_once ABSPATH.'wp-admin/includes/upgrade.php';

    /* ── ec_exams ── */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ec_exams (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        category VARCHAR(255) NOT NULL DEFAULT '',
        difficulty VARCHAR(20) NOT NULL DEFAULT 'Medium',
        pass_mark TINYINT UNSIGNED NOT NULL DEFAULT 60,
        time_limit SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        retake_limit SMALLINT NOT NULL DEFAULT 0,
        negative_marking DECIMAL(3,2) NOT NULL DEFAULT 0.00,
        randomize_questions TINYINT(1) NOT NULL DEFAULT 0,
        randomize_options TINYINT(1) NOT NULL DEFAULT 0,
        question_bank_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        publish_at DATETIME DEFAULT NULL,
        is_published TINYINT(1) NOT NULL DEFAULT 1,
        notes_pdf_url VARCHAR(500) DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY category (category(191)),
        KEY is_published (is_published),
        KEY publish_at (publish_at),
        KEY difficulty (difficulty),
        KEY created_at (created_at)
    ) $c;");

    /* ── ec_questions ── */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ec_questions (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        exam_id INT UNSIGNED NOT NULL,
        question TEXT NOT NULL,
        option_a VARCHAR(512) NOT NULL,
        option_b VARCHAR(512) NOT NULL,
        option_c VARCHAR(512) NOT NULL,
        option_d VARCHAR(512) NOT NULL,
        answer VARCHAR(10) NOT NULL,
        question_type VARCHAR(10) NOT NULL DEFAULT 'single',
        explanation TEXT,
        image_url VARCHAR(500) DEFAULT '',
        tag VARCHAR(255) DEFAULT '',
        difficulty VARCHAR(20) NOT NULL DEFAULT 'Medium',
        sort_order INT UNSIGNED NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY exam_id (exam_id),
        KEY tag (tag(191)),
        KEY exam_sort (exam_id,sort_order),
        KEY difficulty (difficulty)
    ) $c;");

    /* ── ec_results ── */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ec_results (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        exam_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL DEFAULT 0,
        score DECIMAL(8,2) NOT NULL DEFAULT 0,
        total SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        time_taken SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        attempt SMALLINT UNSIGNED NOT NULL DEFAULT 1,
        answers_json LONGTEXT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY exam_id (exam_id),
        KEY user_id (user_id),
        KEY exam_user (exam_id,user_id),
        KEY exam_score (exam_id,score,time_taken),
        KEY created_at (created_at),
        KEY user_created (user_id,created_at),
        UNIQUE KEY uq_exam_user_attempt (exam_id,user_id,attempt)
    ) $c;");

    /* ── ec_schedules ── */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ec_schedules (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        exam_id INT UNSIGNED NOT NULL,
        title VARCHAR(255) NOT NULL DEFAULT '',
        scheduled_date DATE NOT NULL,
        start_time TIME DEFAULT NULL,
        end_time TIME DEFAULT NULL,
        note TEXT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY exam_id (exam_id),
        KEY scheduled_date (scheduled_date),
        KEY exam_schedule (exam_id,scheduled_date,start_time)
    ) $c;");

    /* ── Unique constraint on results (safe to re-run) ── */
    $uq_name = 'uq_exam_user_attempt';
    $uq_table = $wpdb->prefix . 'ec_results';
    $uq_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
         WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = %s AND CONSTRAINT_NAME = %s",
        $uq_table, $uq_name
    ));
    if(!$uq_exists){
        $wpdb->query("ALTER TABLE `{$uq_table}` ADD UNIQUE KEY `{$uq_name}` (`exam_id`,`user_id`,`attempt`)");
    }

    /* ── Foreign key constraints (InnoDB only, safe to re-run) ── */
    $fks = array(
        array('ec_questions', 'fk_ecq_exam', 'exam_id', 'ec_exams', 'id', 'CASCADE'),
        array('ec_results',   'fk_ecr_exam', 'exam_id', 'ec_exams', 'id', 'CASCADE'),
        array('ec_schedules', 'fk_ecs_exam', 'exam_id', 'ec_exams', 'id', 'CASCADE'),
    );
    foreach($fks as $fk){
        $table  = $wpdb->prefix . $fk[0];
        $name   = $fk[1];
        $col    = $fk[2];
        $ref_t  = $wpdb->prefix . $fk[3];
        $ref_c  = $fk[4];
        $on_del = $fk[5];
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
             WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = %s AND CONSTRAINT_NAME = %s AND CONSTRAINT_TYPE = 'FOREIGN KEY'",
            $table, $name
        ));
        if(!$exists){
            $wpdb->query("ALTER TABLE `{$table}` ADD CONSTRAINT `{$name}` FOREIGN KEY (`{$col}`) REFERENCES `{$ref_t}` (`{$ref_c}`) ON DELETE {$on_del}");
        }
    }

    update_option('ec_db_ver',EC_VER);
}
register_activation_hook(__FILE__,'ec_install');
add_action('plugins_loaded',function(){if(get_option('ec_db_ver')!==EC_VER)ec_install();});

/* Auto-publish cron */
add_action('ec_auto_publish','ec_run_auto_publish');
function ec_run_auto_publish(){global $wpdb;$wpdb->query("UPDATE {$wpdb->prefix}ec_exams SET is_published=1 WHERE publish_at IS NOT NULL AND publish_at<=NOW() AND is_published=0");}
if(!wp_next_scheduled('ec_auto_publish'))wp_schedule_event(time(),'hourly','ec_auto_publish');

/* ══ DB HELPERS (extended) ══ */
function ec_exams(){global $wpdb;return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ec_exams ORDER BY created_at DESC");}
function ec_exam($id){global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ec_exams WHERE id=%d",$id));}
function ec_ins_exam($d){global $wpdb;$wpdb->insert("{$wpdb->prefix}ec_exams",$d);return $wpdb->insert_id;}
function ec_upd_exam($id,$d){global $wpdb;$wpdb->update("{$wpdb->prefix}ec_exams",$d,array('id'=>$id));}
function ec_del_exam($id){global $wpdb;$wpdb->delete("{$wpdb->prefix}ec_exams",array('id'=>$id));$wpdb->delete("{$wpdb->prefix}ec_questions",array('exam_id'=>$id));$wpdb->delete("{$wpdb->prefix}ec_results",array('exam_id'=>$id));$wpdb->delete("{$wpdb->prefix}ec_schedules",array('exam_id'=>$id));ec_invalidate_caches($id);}
function ec_questions($eid){global $wpdb;return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ec_questions WHERE exam_id=%d ORDER BY sort_order,id",$eid));}
function ec_question($id){global $wpdb;return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ec_questions WHERE id=%d",$id));}
function ec_ins_q($d){global $wpdb;$wpdb->insert("{$wpdb->prefix}ec_questions",$d);return $wpdb->insert_id;}
function ec_upd_q($id,$d){global $wpdb;$wpdb->update("{$wpdb->prefix}ec_questions",$d,array('id'=>$id));}
function ec_del_q($id){global $wpdb;$wpdb->delete("{$wpdb->prefix}ec_questions",array('id'=>$id));}
function ec_qcount($eid){global $wpdb;return(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ec_questions WHERE exam_id=%d",$eid));}
function ec_ins_result($d){global $wpdb;$wpdb->insert("{$wpdb->prefix}ec_results",$d);$id=$wpdb->insert_id;ec_invalidate_caches($d['exam_id']??0,$d['user_id']??0);return $id;}
function ec_invalidate_caches($eid=0,$uid=0){
    if($eid){delete_transient('ec_analytics_'.$eid);delete_transient('ec_lb_'.$eid.'_20');delete_transient('ec_lb_'.$eid.'_30');}
    if($uid)delete_transient('ec_student_'.$uid);
}
function ec_all_results($eid){global $wpdb;return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ec_results WHERE exam_id=%d ORDER BY score DESC,time_taken ASC",$eid));}
function ec_user_attempts($eid,$uid){global $wpdb;return(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ec_results WHERE exam_id=%d AND user_id=%d",$eid,$uid));}
function ec_leaderboard($eid,$lim=20){
    $cache_key = 'ec_lb_' . $eid . '_' . $lim;
    $cached = get_transient($cache_key);
    if($cached !== false) return $cached;
    global $wpdb;
    $results = $wpdb->get_results($wpdb->prepare("SELECT r.*,u.display_name FROM {$wpdb->prefix}ec_results r LEFT JOIN {$wpdb->users} u ON r.user_id=u.ID WHERE r.exam_id=%d ORDER BY r.score DESC,r.time_taken ASC LIMIT %d",$eid,$lim));
    set_transient($cache_key, $results, 3 * MINUTE_IN_SECONDS);
    return $results;
}
function ec_check_tables(){global $wpdb;return $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}ec_exams'")===$wpdb->prefix.'ec_exams';}
function ec_paged_results($eid,$page=1,$per=20){global $wpdb;$off=($page-1)*$per;return $wpdb->get_results($wpdb->prepare("SELECT r.*,u.display_name FROM {$wpdb->prefix}ec_results r LEFT JOIN {$wpdb->users} u ON r.user_id=u.ID WHERE r.exam_id=%d ORDER BY r.created_at DESC LIMIT %d OFFSET %d",$eid,$per,$off));}
function ec_result_count($eid){global $wpdb;return(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ec_results WHERE exam_id=%d",$eid));}
function ec_all_schedules(){global $wpdb;return $wpdb->get_results("SELECT s.*,e.title as exam_title FROM {$wpdb->prefix}ec_schedules s LEFT JOIN {$wpdb->prefix}ec_exams e ON s.exam_id=e.id ORDER BY s.scheduled_date ASC");}
function ec_upcoming_schedules($days=7){global $wpdb;return $wpdb->get_results($wpdb->prepare("SELECT s.*,e.title as exam_title FROM {$wpdb->prefix}ec_schedules s LEFT JOIN {$wpdb->prefix}ec_exams e ON s.exam_id=e.id WHERE s.scheduled_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL %d DAY) ORDER BY s.scheduled_date ASC",$days));}
function ec_get_exam_schedule($exam_id){
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ec_schedules WHERE exam_id=%d AND scheduled_date>=CURDATE() ORDER BY scheduled_date ASC, start_time ASC LIMIT 1",$exam_id));
}
function ec_is_exam_available($exam){
    $now = current_time('U');
    $schedule = ec_get_exam_schedule($exam->id);
    if($schedule){
        $start_dt = strtotime($schedule->scheduled_date.' '.($schedule->start_time ?: '00:00:00'));
        $end_dt = $schedule->end_time ? strtotime($schedule->scheduled_date.' '.$schedule->end_time) : null;
        if($now < $start_dt){
            return array('available'=>false, 'message'=>sprintf('🔒 This exam will open on <strong>%s</strong>.', date_i18n(get_option('date_format').' \a\t '.get_option('time_format'), $start_dt)));
        }
        if($end_dt && $now > $end_dt){
            return array('available'=>false, 'message'=>'⏰ This exam window has closed.');
        }
    }
    if(!$exam->is_published){
        if($exam->publish_at && strtotime($exam->publish_at) > $now)
            return array('available'=>false, 'message'=>sprintf('🔒 This exam will be available on <strong>%s</strong>.', date_i18n(get_option('date_format').' \a\t '.get_option('time_format'), strtotime($exam->publish_at))));
        else
            return array('available'=>false, 'message'=>'This exam is not published yet.');
    }
    return array('available'=>true, 'message'=>'');
}

/* Multi-category & multi-tag helpers */
function ec_get_exams_by_category($cats_str){
    global $wpdb;
    $cats = array_map('trim', explode(',', $cats_str));
    $conditions = array();
    foreach($cats as $cat){
        $conditions[] = $wpdb->prepare("FIND_IN_SET(%s, category) > 0", $cat);
    }
    $sql = "SELECT * FROM {$wpdb->prefix}ec_exams WHERE (".implode(' OR ', $conditions).") ORDER BY created_at DESC";
    return $wpdb->get_results($sql);
}
function ec_get_exams_by_tag($tag_str){
    global $wpdb;
    $tags = array_map('trim', explode(',', $tag_str));
    $conditions = array();
    foreach($tags as $tag){
        $conditions[] = $wpdb->prepare("FIND_IN_SET(%s, tag) > 0", $tag);
    }
    $sql = "SELECT DISTINCT e.* FROM {$wpdb->prefix}ec_exams e JOIN {$wpdb->prefix}ec_questions q ON e.id=q.exam_id WHERE (".implode(' OR ', $conditions).") ORDER BY e.created_at DESC";
    return $wpdb->get_results($sql);
}

function ec_exam_analytics($eid){
    $cache_key = 'ec_analytics_' . $eid;
    $cached = get_transient($cache_key);
    if($cached !== false) return $cached;

    global $wpdb; $t="{$wpdb->prefix}ec_results"; $s=new stdClass();
    $s->total_attempts=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE exam_id=%d",$eid));
    $s->unique_users=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT user_id) FROM $t WHERE exam_id=%d",$eid));
    $s->avg_score=(float)$wpdb->get_var($wpdb->prepare("SELECT AVG(score/total*100) FROM $t WHERE exam_id=%d AND total>0",$eid));
    $s->avg_time=(float)$wpdb->get_var($wpdb->prepare("SELECT AVG(time_taken) FROM $t WHERE exam_id=%d",$eid));
    $s->highest=(float)$wpdb->get_var($wpdb->prepare("SELECT MAX(score) FROM $t WHERE exam_id=%d",$eid));
    $s->lowest=(float)$wpdb->get_var($wpdb->prepare("SELECT MIN(score) FROM $t WHERE exam_id=%d AND total>0",$eid));
    $exam=ec_exam($eid); $pm=$exam?(int)$exam->pass_mark:60;
    $s->pass_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE exam_id=%d AND total>0 AND (score/total*100)>=%d",$eid,(int)$pm));
    $s->fail_count=$s->total_attempts-$s->pass_count;
    $s->pass_rate=$s->total_attempts>0?round($s->pass_count/$s->total_attempts*100,1):0;
    $s->dist=$wpdb->get_results($wpdb->prepare("SELECT FLOOR(score/total*10)*10 AS bracket,COUNT(*) AS cnt FROM $t WHERE exam_id=%d AND total>0 GROUP BY bracket ORDER BY bracket",$eid));
    $s->tags=$wpdb->get_results($wpdb->prepare("SELECT q.tag,COUNT(DISTINCT r.id) as attempts,AVG(r.score/r.total*100) as avg_pct FROM {$wpdb->prefix}ec_questions q JOIN {$wpdb->prefix}ec_results r ON r.exam_id=q.exam_id WHERE q.exam_id=%d AND q.tag!='' GROUP BY q.tag ORDER BY q.tag",$eid));
    $s->trend=$wpdb->get_results($wpdb->prepare("SELECT DATE(created_at) as dt,AVG(score/total*100) as avg_pct FROM $t WHERE exam_id=%d AND total>0 GROUP BY DATE(created_at) ORDER BY dt ASC LIMIT 30",$eid));

    set_transient($cache_key, $s, 5 * MINUTE_IN_SECONDS);
    return $s;
}

function ec_student_analytics($uid){
    $cache_key = 'ec_student_' . $uid;
    $cached = get_transient($cache_key);
    if($cached !== false) return $cached;
    global $wpdb;
    $results = $wpdb->get_results($wpdb->prepare("SELECT r.*,e.title as exam_title,e.pass_mark FROM {$wpdb->prefix}ec_results r JOIN {$wpdb->prefix}ec_exams e ON r.exam_id=e.id WHERE r.user_id=%d ORDER BY r.created_at DESC",$uid));
    set_transient($cache_key, $results, 5 * MINUTE_IN_SECONDS);
    return $results;
}
function ec_weak_questions($uid,$eid){
    global $wpdb;
    $results=$wpdb->get_results($wpdb->prepare("SELECT answers_json FROM {$wpdb->prefix}ec_results WHERE user_id=%d AND exam_id=%d ORDER BY created_at DESC LIMIT 5",$uid,$eid));
    $wc=array();
    foreach($results as $r){$d=json_decode($r->answers_json,true);if(!$d)continue;foreach($d as $q){if(!$q['correct']){$id=$q['q_id'];$wc[$id]=($wc[$id]??0)+1;}}}
    arsort($wc);return $wc;
}
function ec_allowed_html(){return array('br'=>array(),'strong'=>array(),'b'=>array(),'em'=>array(),'i'=>array(),'u'=>array(),'sup'=>array(),'sub'=>array(),'span'=>array('style'=>array(),'class'=>array()),'mark'=>array(),'img'=>array('src'=>array(),'alt'=>array(),'width'=>array(),'height'=>array(),'class'=>array()),'p'=>array('style'=>array(),'class'=>array()),'table'=>array('style'=>array(),'class'=>array(),'border'=>array(),'cellpadding'=>array(),'cellspacing'=>array()),'thead'=>array(),'tbody'=>array(),'tfoot'=>array(),'tr'=>array('style'=>array(),'class'=>array()),'th'=>array('style'=>array(),'class'=>array(),'colspan'=>array(),'rowspan'=>array()),'td'=>array('style'=>array(),'class'=>array(),'colspan'=>array(),'rowspan'=>array()),'ul'=>array('style'=>array(),'class'=>array()),'ol'=>array('style'=>array(),'class'=>array()),'li'=>array('style'=>array(),'class'=>array()),'h3'=>array(),'h4'=>array(),'h5'=>array(),'div'=>array('style'=>array(),'class'=>array()),'pre'=>array(),'code'=>array(),'hr'=>array(),'blockquote'=>array());}
function ec_sanitize_html($t){return wp_kses(trim($t),ec_allowed_html());}
function ec_kses($t){return wp_kses($t,ec_allowed_html());}

/* ══ ADMIN MENU ══ */
add_action('admin_menu',function(){
    add_menu_page('ExamCraft','🎓 ExamCraft','manage_options','ec','ec_page_dashboard','dashicons-welcome-learn-more',26);
    add_submenu_page('ec','All Exams','All Exams','manage_options','ec','ec_page_dashboard');
    add_submenu_page('ec','Add Exam','Add Exam','manage_options','ec-add-exam','ec_page_add_exam');
    add_submenu_page('ec','Questions','Questions','manage_options','ec-questions','ec_page_questions');
    add_submenu_page('ec','Import CSV','Import Questions','manage_options','ec-import','ec_page_import');
    add_submenu_page('ec','Results','Results','manage_options','ec-results','ec_page_results');
    add_submenu_page('ec','Analytics','📊 Analytics','manage_options','ec-analytics','ec_page_analytics');
    add_submenu_page('ec','Students','👤 Students','manage_options','ec-students','ec_page_students');
    add_submenu_page('ec','Schedule','🗓 Schedule','manage_options','ec-schedule','ec_page_schedule');
    add_submenu_page('ec','CSV Export','📤 CSV Export','manage_options','ec-export','ec_page_export');
});

/* ══ ADMIN CSS (unchanged) ══ */
add_action('admin_head',function(){
    $scr=get_current_screen();
    if(!$scr||strpos($scr->id,'ec')===false)return;
    echo '<style>
@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap&font-display=swap");
.ec-wrap{font-family:Inter,sans-serif!important;max-width:1200px}.ec-wrap *{box-sizing:border-box}
.ec-ph{background:linear-gradient(135deg,#1e3a8a,#2563eb);border-radius:12px;padding:18px 24px;margin:8px 0 20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;box-shadow:0 4px 20px rgba(37,99,235,.3)}
.ec-ph h1{margin:0;font-size:20px;font-weight:800;color:#fff}.ec-ph-sub{font-size:12px;color:rgba(255,255,255,.7);margin-top:2px}.ec-ph-btns{display:flex;gap:8px;flex-wrap:wrap}
.ec-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:18px}
.ec-stat{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:16px 20px;display:flex;align-items:center;gap:12px;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.ec-stat-ico{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.ec-stat-ico.bl{background:#eff6ff}.ec-stat-ico.gr{background:#f0fdf4}.ec-stat-ico.pu{background:#f5f3ff}.ec-stat-ico.am{background:#fffbeb}.ec-stat-ico.te{background:#f0fdfa}
.ec-stat strong{display:block;font-size:22px;font-weight:800;color:#0f172a;line-height:1}.ec-stat span{font-size:11px;color:#94a3b8;font-weight:600;margin-top:2px;display:block}
.ec-card{background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 1px 4px rgba(0,0,0,.05);margin-bottom:16px;overflow:hidden}
.ec-ch{display:flex;align-items:center;justify-content:space-between;padding:14px 20px;border-bottom:1px solid #e2e8f0;background:#f8fafc;flex-wrap:wrap;gap:8px}
.ec-ct{margin:0;font-size:14px;font-weight:800;color:#0f172a;display:flex;align-items:center;gap:6px}.ec-ct::before{content:"";display:inline-block;width:3px;height:15px;background:#2563eb;border-radius:2px}
.ec-cb{padding:20px}
.ec-tbl{width:100%;border-collapse:collapse}.ec-tbl th{background:#f8fafc;padding:10px 12px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#64748b;text-align:left;border-bottom:1px solid #e2e8f0;font-weight:700}
.ec-tbl td{padding:10px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;color:#334155;vertical-align:middle}.ec-tbl tr:hover{background:#fafbff}.ec-edit-row{background:#eff6ff!important}
.ec-field{margin-bottom:14px}.ec-field label{display:block;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#475569;margin-bottom:5px}
.ec-field input,.ec-field textarea,.ec-field select,.ec-select{width:100%;padding:9px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;font-family:inherit;background:#fff;transition:border-color .2s}
.ec-field input:focus,.ec-field textarea:focus,.ec-field select:focus,.ec-select:focus{border-color:#2563eb;outline:none;box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.ec-grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.ec-grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
.ec-hint{font-size:11px;color:#94a3b8;margin-top:3px}.ec-req{color:#ef4444}
.ec-two{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:768px){.ec-two,.ec-grid2,.ec-grid3{grid-template-columns:1fr}}
.ec-pre{background:#1e293b;color:#e2e8f0;padding:12px 16px;border-radius:8px;font-size:12px;overflow-x:auto}
.fmt-tbl{width:100%;border-collapse:collapse;font-size:12px;margin-top:6px}
.fmt-tbl th{background:#eff6ff;padding:6px 10px;text-align:center;border:1px solid #e2e8f0;color:#1e40af;font-weight:700}
.fmt-tbl td{padding:6px 10px;text-align:center;border:1px solid #e2e8f0;color:#334155}
.btn{display:inline-block;padding:7px 14px;border-radius:8px;font-size:12px;font-weight:700;font-family:inherit;text-decoration:none;cursor:pointer;border:1.5px solid #e2e8f0;background:#fff;color:#334155;transition:all .2s;line-height:1.4}
.btn:hover{border-color:#2563eb;color:#2563eb;text-decoration:none}
.btn-primary{background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff!important;border-color:transparent}.btn-primary:hover{opacity:.9;color:#fff!important}
.btn-danger{color:#ef4444;border-color:#fecaca}.btn-danger:hover{background:#fef2f2;color:#dc2626;border-color:#ef4444}
.btn-white{background:rgba(255,255,255,.18);color:#fff;border-color:rgba(255,255,255,.3)}.btn-white:hover{background:rgba(255,255,255,.3);color:#fff}
.btn-success{background:linear-gradient(135deg,#16a34a,#15803d);color:#fff!important;border-color:transparent}
.btn-sm{padding:4px 10px;font-size:11px}.btn-lg{padding:9px 20px;font-size:13px}
.pill{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700}
.pill-blue{background:#eff6ff;color:#2563eb}.pill-green{background:#f0fdf4;color:#16a34a}.pill-red{background:#fef2f2;color:#ef4444}.pill-gray{background:#f8fafc;color:#64748b}.pill-amber{background:#fffbeb;color:#d97706}
.ans-pill{background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700}
.ec-notice{padding:12px 18px;border-radius:8px;margin-bottom:14px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px}
.ec-notice.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534}.ec-notice.err{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
.ec-pagination{display:flex;gap:4px;align-items:center;justify-content:center;margin:16px 0;flex-wrap:wrap}
.ec-pagination a,.ec-pagination span{display:inline-block;padding:6px 12px;border-radius:6px;font-size:12px;font-weight:700;text-decoration:none;border:1px solid #e2e8f0;color:#334155}
.ec-pagination a:hover{background:#eff6ff;border-color:#2563eb;color:#2563eb}.ec-pagination .current{background:#2563eb;color:#fff;border-color:#2563eb}
.ec-chart-bar{display:flex;align-items:flex-end;gap:6px;height:120px;margin:12px 0}
.ec-chart-bar div{background:linear-gradient(to top,#2563eb,#60a5fa);border-radius:4px 4px 0 0;min-width:28px;position:relative;transition:height .3s}
.ec-chart-bar div span{position:absolute;top:-16px;left:50%;transform:translateX(-50%);font-size:10px;font-weight:700;color:#334155}
.ec-chart-bar div em{position:absolute;bottom:-18px;left:50%;transform:translateX(-50%);font-size:9px;color:#94a3b8;font-style:normal;white-space:nowrap}
.ec-countdown{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:#fef3c7;color:#92400e;border:1px solid #fde68a}
.ec-countdown.today{background:#dcfce7;color:#166534;border-color:#86efac}.ec-countdown.overdue{background:#fee2e2;color:#991b1b;border-color:#fecaca}
.ec-timeline{position:relative;padding-left:24px}.ec-timeline::before{content:"";position:absolute;left:8px;top:0;bottom:0;width:2px;background:#e2e8f0}
.ec-tl-item{position:relative;margin-bottom:16px}
.ec-tl-dot{position:absolute;left:-20px;top:4px;width:12px;height:12px;border-radius:50%;background:#2563eb;border:2px solid #fff;box-shadow:0 0 0 2px #2563eb}
.ec-tl-dot.past{background:#94a3b8;box-shadow:0 0 0 2px #94a3b8}.ec-tl-dot.today{background:#16a34a;box-shadow:0 0 0 2px #16a34a}
</style>';
});

/* ══ SHARED UI HELPERS ══ */
function ec_ph($title,$sub='',$btns=''){
    echo '<div class="ec-ph"><div><h1>'.esc_html($title).'</h1>';
    if($sub)echo '<div class="ec-ph-sub">'.esc_html($sub).'</div>';
    echo '</div>';
    if($btns)echo '<div class="ec-ph-btns">'.$btns.'</div>';
    echo '</div>';
}
function ec_notice($msg){
    $map=array('saved'=>array('ok','✅ Saved.'),'deleted'=>array('ok','🗑 Deleted.'),'imported'=>array('ok','📥 Imported.'),'published'=>array('ok','🚀 Published.'),'error'=>array('err','⚠️ Error.'),'noperm'=>array('err','🔒 No permission.'),'maxretake'=>array('err','🔒 Retake limit reached.'));
    if($msg&&isset($map[$msg]))echo '<div class="ec-notice '.$map[$msg][0].'">'.$map[$msg][1].'</div>';
}
function ec_exam_picker($page,$title){
    $exams=ec_exams();echo '<div class="wrap ec-wrap">';
    ec_ph('📝 '.esc_html($title),'Select an exam','<a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Exams</a>');
    if(!$exams){echo '<p>No exams yet. <a href="'.admin_url('admin.php?page=ec-add-exam').'">Create one</a>.</p></div>';return;}
    echo '<div class="ec-card"><div class="ec-cb"><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px">';
    foreach($exams as $e){
        echo '<a href="'.admin_url('admin.php?page='.$page.'&exam_id='.$e->id).'" class="btn" style="text-align:left;padding:14px">';
        echo '<strong style="display:block;margin-bottom:4px">'.esc_html($e->title).'</strong>';
        echo '<span style="font-size:11px;color:#94a3b8">'.ec_qcount($e->id).' Qs · '.esc_html($e->category?:'Uncategorized').'</span></a>';
    }
    echo '</div></div></div></div>';
}
function ec_countdown_label($date){
    $diff=(int)round((strtotime($date)-strtotime(date('Y-m-d')))/86400);
    if($diff<0)return '<span class="ec-countdown overdue">Past</span>';
    if($diff===0)return '<span class="ec-countdown today">Today</span>';
    if($diff===1)return '<span class="ec-countdown">Tomorrow</span>';
    return '<span class="ec-countdown">In '.$diff.' days</span>';
}

/* ══ ADMIN FORM PROCESSING (extended for multi-category/tag) ══ */
add_action('admin_init',function(){
    if(!isset($_REQUEST['ec_action']))return;
    ec_require_admin();
    $action=sanitize_key($_REQUEST['ec_action']);
    if(in_array($action,array('delete_exam','delete_q','delete_schedule','publish_exam'))){ec_verify_url_nonce();}
    else{ec_verify_nonce();}

    switch($action){
        case 'add_exam': case 'edit_exam':
            $pub=!empty($_POST['publish_at'])?sanitize_text_field($_POST['publish_at']):null;
            $isp=isset($_POST['is_published'])?1:0;
            if($pub&&strtotime($pub)>time())$isp=0;
            $d=array(
                'title'=>sanitize_text_field($_POST['title']),
                'description'=>ec_sanitize_html($_POST['description']??''),
                'category'=>sanitize_text_field($_POST['category']??''),
                'difficulty'=>sanitize_text_field($_POST['difficulty']??'Medium'),
                'pass_mark'=>absint($_POST['pass_mark']??60),
                'time_limit'=>absint($_POST['time_limit']??0),
                'retake_limit'=>intval($_POST['retake_limit']??0),
                'negative_marking'=>floatval($_POST['negative_marking']??0),
                'randomize_questions'=>isset($_POST['randomize_questions'])?1:0,
                'randomize_options'=>isset($_POST['randomize_options'])?1:0,
                'question_bank_count'=>absint($_POST['question_bank_count']??0),
                'publish_at'=>$pub,'is_published'=>$isp,
                'notes_pdf_url'=>esc_url_raw($_POST['notes_pdf_url']??''),
            );
            if($action==='add_exam'){$id=ec_ins_exam($d);wp_redirect(admin_url('admin.php?page=ec-questions&exam_id='.$id.'&msg=saved'));}
            else{ec_upd_exam(absint($_POST['exam_id']),$d);wp_redirect(admin_url('admin.php?page=ec&msg=saved'));}
            exit;

        case 'delete_exam': ec_del_exam(absint($_GET['exam_id']));wp_redirect(admin_url('admin.php?page=ec&msg=deleted'));exit;
        case 'publish_exam': ec_upd_exam(absint($_GET['exam_id']),array('is_published'=>1,'publish_at'=>null));wp_redirect(admin_url('admin.php?page=ec&msg=published'));exit;

        case 'add_q': case 'edit_q':
            $eid=absint($_POST['exam_id']);
            $qd=array('exam_id'=>$eid,'question'=>ec_sanitize_html($_POST['question']),'option_a'=>ec_sanitize_html($_POST['option_a']),'option_b'=>ec_sanitize_html($_POST['option_b']),'option_c'=>ec_sanitize_html($_POST['option_c']),'option_d'=>ec_sanitize_html($_POST['option_d']),'answer'=>strtoupper(sanitize_text_field($_POST['answer'])),'question_type'=>sanitize_text_field($_POST['question_type']??'single'),'explanation'=>ec_sanitize_html($_POST['explanation']??''),'image_url'=>esc_url_raw($_POST['image_url']??''),'tag'=>sanitize_text_field($_POST['tag']??''),'difficulty'=>sanitize_text_field($_POST['q_difficulty']??'Medium'),'sort_order'=>absint($_POST['sort_order']??0));
            if($action==='add_q')ec_ins_q($qd);
            else ec_upd_q(absint($_POST['q_id']),$qd);
            wp_redirect(admin_url('admin.php?page=ec-questions&exam_id='.$eid.'&msg=saved'));exit;

        case 'delete_q':
            $q=ec_question(absint($_GET['q_id']));
            if($q){ec_del_q($q->id);wp_redirect(admin_url('admin.php?page=ec-questions&exam_id='.$q->exam_id.'&msg=deleted'));}
            else wp_redirect(admin_url('admin.php?page=ec&msg=error'));
            exit;

        case 'import_csv':
            $eid=absint($_POST['exam_id']);
            if(!$eid||empty($_FILES['csv_file']['tmp_name'])){wp_redirect(admin_url('admin.php?page=ec-import&msg=error'));exit;}
            $h=fopen($_FILES['csv_file']['tmp_name'],'r');if(!$h){wp_redirect(admin_url('admin.php?page=ec-import&msg=error'));exit;}$row=0;$imp=0;
            while(($data=fgetcsv($h))!==false){$row++;if($row===1)continue;if(count($data)<6)continue;
                ec_ins_q(array('exam_id'=>$eid,'question'=>ec_sanitize_html($data[0]),'option_a'=>ec_sanitize_html($data[1]),'option_b'=>ec_sanitize_html($data[2]),'option_c'=>ec_sanitize_html($data[3]),'option_d'=>ec_sanitize_html($data[4]),'answer'=>strtoupper(sanitize_text_field($data[5])),'explanation'=>isset($data[6])?ec_sanitize_html($data[6]):'','tag'=>isset($data[7])?sanitize_text_field($data[7]):'','difficulty'=>isset($data[8])?sanitize_text_field($data[8]):'Medium','sort_order'=>$imp));$imp++;
            }
            fclose($h);wp_redirect(admin_url('admin.php?page=ec-questions&exam_id='.$eid.'&msg=imported'));exit;

        case 'email_result':
            global $wpdb;$rid=absint($_POST['result_id']);
            $result=$wpdb->get_row($wpdb->prepare("SELECT r.*,e.title as exam_title FROM {$wpdb->prefix}ec_results r JOIN {$wpdb->prefix}ec_exams e ON r.exam_id=e.id WHERE r.id=%d",$rid));
            if($result&&$result->user_id){$user=get_userdata($result->user_id);if($user&&$user->user_email){$pct=$result->total>0?round($result->score/$result->total*100,1):0;wp_mail($user->user_email,'Your Exam Result: '.sanitize_text_field($result->exam_title),"Hi ".sanitize_text_field($user->display_name).",\n\nScore: ".$result->score."/".$result->total." (".$pct."%)\nTime: ".gmdate('i:s',$result->time_taken)."\nDate: ".$result->created_at."\n\n— ".get_bloginfo('name'));}}
            $rid2=$result?$result->exam_id:0;wp_redirect(admin_url('admin.php?page=ec-results'.($rid2?'&exam_id='.$rid2:'').'&msg=saved'));exit;

        case 'save_schedule':
            global $wpdb;$sid=absint($_POST['schedule_id']??0);
            $sd=array('exam_id'=>absint($_POST['exam_id']),'title'=>sanitize_text_field($_POST['sched_title']??''),'scheduled_date'=>sanitize_text_field($_POST['scheduled_date']),'start_time'=>!empty($_POST['start_time'])?sanitize_text_field($_POST['start_time']):null,'end_time'=>!empty($_POST['end_time'])?sanitize_text_field($_POST['end_time']):null,'note'=>sanitize_textarea_field($_POST['note']??''));
            if($sid)$wpdb->update("{$wpdb->prefix}ec_schedules",$sd,array('id'=>$sid));
            else $wpdb->insert("{$wpdb->prefix}ec_schedules",$sd);
            wp_redirect(admin_url('admin.php?page=ec-schedule&msg=saved'));exit;

        case 'delete_schedule':
            global $wpdb;$wpdb->delete("{$wpdb->prefix}ec_schedules",array('id'=>absint($_GET['schedule_id'])));
            wp_redirect(admin_url('admin.php?page=ec-schedule&msg=deleted'));exit;
    }
});

/* ══ PAGE: DASHBOARD (unchanged) ══ */
function ec_page_dashboard(){
    ec_require_admin();if(!ec_check_tables())ec_install();
    $exams=ec_exams();$tq=0;$tr=0;
    foreach($exams as $e){$tq+=ec_qcount($e->id);$tr+=ec_result_count($e->id);}
    global $wpdb;$upcoming=ec_upcoming_schedules(7);
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('🎓 ExamCraft','v3.1 — Multi-category & Schedule Control','<a href="'.admin_url('admin.php?page=ec-add-exam').'" class="btn btn-white">+ New Exam</a><a href="'.admin_url('admin.php?page=ec-schedule').'" class="btn btn-white">🗓 Schedule</a><a href="'.admin_url('admin.php?page=ec-analytics').'" class="btn btn-white">📊 Analytics</a><a href="'.admin_url('admin.php?page=ec-students').'" class="btn btn-white">👤 Students</a>');?>
    <?php ec_notice(sanitize_key($_GET['msg']??''));?>
    <?php if($upcoming):?>
    <div class="ec-card" style="border-left:4px solid #2563eb">
        <div class="ec-ch"><h2 class="ec-ct">📅 Upcoming This Week</h2></div>
        <div class="ec-cb" style="padding:14px 20px"><div style="display:flex;flex-wrap:wrap;gap:10px">
        <?php foreach($upcoming as $s):?>
        <div style="background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;padding:12px 16px;min-width:180px">
            <div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:3px"><?php echo date('D, M j',strtotime($s->scheduled_date));?></div>
            <div style="font-weight:700;color:#0f172a;margin-bottom:3px"><?php echo esc_html($s->exam_title);?></div>
            <?php if($s->title):?><div style="font-size:12px;color:#64748b;margin-bottom:4px"><?php echo esc_html($s->title);?></div><?php endif;?>
            <?php echo ec_countdown_label($s->scheduled_date);?>
        </div>
        <?php endforeach;?>
        </div></div>
    </div>
    <?php endif;?>
    <div class="ec-stats">
        <div class="ec-stat"><div class="ec-stat-ico bl">📝</div><div><strong><?php echo count($exams);?></strong><span>EXAMS</span></div></div>
        <div class="ec-stat"><div class="ec-stat-ico gr">❓</div><div><strong><?php echo $tq;?></strong><span>QUESTIONS</span></div></div>
        <div class="ec-stat"><div class="ec-stat-ico pu">🏆</div><div><strong><?php echo $tr;?></strong><span>ATTEMPTS</span></div></div>
        <div class="ec-stat"><div class="ec-stat-ico am">👥</div><div><strong><?php echo(int)$wpdb->get_var("SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}ec_results");?></strong><span>STUDENTS</span></div></div>
    </div>
    <?php if($exams):?>
    <div class="ec-card">
        <div class="ec-ch"><h2 class="ec-ct">All Exams</h2></div>
        <table class="ec-tbl">
            <thead><tr><th>Title</th><th>Status</th><th>Category</th><th>Pass%</th><th>Timer</th><th>Qs</th><th>Shortcode</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach($exams as $e):$qc=ec_qcount($e->id);?>
            <tr>
                <td style="font-weight:700"><?php echo esc_html($e->title);?><?php if(!empty($e->notes_pdf_url)):?> <a href="<?php echo esc_url($e->notes_pdf_url);?>" target="_blank" title="Short Notes PDF">📄</a><?php endif;?></td>
                <td><?php if($e->is_published):?><span class="pill pill-green">✅ Live</span><?php elseif($e->publish_at):?><span class="pill pill-amber" title="<?php echo esc_attr(date('M j, Y g:i a',strtotime($e->publish_at)));?>">⏰ Scheduled</span><?php else:?><span class="pill pill-gray">Draft</span><?php endif;?></td>
                <td><span class="pill pill-blue"><?php echo esc_html($e->category?:'—');?></span></td>
                <td><?php echo(int)$e->pass_mark;?>%</td>
                <td><?php echo $e->time_limit?$e->time_limit.'m':'∞';?></td>
                <td><span class="pill pill-green"><?php echo $qc;?></span></td>
                <td><code style="font-size:11px;background:#f1f5f9;padding:3px 8px;border-radius:4px">[examcraft id=<?php echo $e->id;?>]</code></td>
                <td><div style="display:flex;gap:4px;flex-wrap:wrap">
                    <a href="<?php echo admin_url('admin.php?page=ec-questions&exam_id='.$e->id);?>" class="btn btn-sm">❓</a>
                    <a href="<?php echo admin_url('admin.php?page=ec-add-exam&edit='.$e->id);?>" class="btn btn-sm">✏️</a>
                    <a href="<?php echo admin_url('admin.php?page=ec-results&exam_id='.$e->id);?>" class="btn btn-sm">🏆</a>
                    <a href="<?php echo admin_url('admin.php?page=ec-analytics&exam_id='.$e->id);?>" class="btn btn-sm">📊</a>
                    <?php if(!$e->is_published):?><a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ec&ec_action=publish_exam&exam_id='.$e->id),'ec_nonce');?>" class="btn btn-sm btn-success" title="Publish Now">🚀</a><?php endif;?>
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ec&ec_action=delete_exam&exam_id='.$e->id),'ec_nonce');?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete exam and all data?')">🗑</a>
                </div></td>
            </tr>
            <?php endforeach;?>
            </tbody>
        </table>
    </div>
    <?php else:?>
    <div style="background:#f8fafc;border:2px dashed #e2e8f0;border-radius:12px;padding:30px;text-align:center">
        <p style="font-size:16px;font-weight:700;color:#0f172a;margin:0 0 4px">No exams yet</p>
        <a href="<?php echo admin_url('admin.php?page=ec-add-exam');?>" class="btn btn-primary btn-lg">+ Create Exam</a>
    </div>
    <?php endif;?>
    </div>
    <?php
}

/* ══ PAGE: ADD/EDIT EXAM (with multi-category hint) ══ */
function ec_page_add_exam(){
    ec_require_admin();$is_edit=isset($_GET['edit']);
    $exam=$is_edit?ec_exam(absint($_GET['edit'])):null;
    if($is_edit&&!$exam){echo '<div class="wrap"><p>Exam not found.</p></div>';return;}
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph($is_edit?'✏️ Edit Exam':'➕ New Exam','','<a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Back</a>');?>
    <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct"><?php echo $is_edit?'Edit Details':'Exam Details';?></h2></div><div class="ec-cb">
    <form method="post">
        <?php ec_nonce();?>
        <input type="hidden" name="ec_action" value="<?php echo $is_edit?'edit_exam':'add_exam';?>">
        <?php if($is_edit):?><input type="hidden" name="exam_id" value="<?php echo(int)$exam->id;?>"><?php endif;?>
        <div class="ec-field"><label>Exam Title <span class="ec-req">*</span></label><input type="text" name="title" required value="<?php echo esc_attr($exam?$exam->title:'');?>" placeholder="e.g. Biology Final Exam"></div>
        <div class="ec-field"><label>Description</label><textarea name="description" rows="2"><?php echo esc_textarea($exam?$exam->description:'');?></textarea></div>
        <div class="ec-grid2">
            <div class="ec-field"><label>Category <span class="ec-hint">(comma separated)</span></label><input type="text" name="category" value="<?php echo esc_attr($exam?$exam->category:'');?>" placeholder="e.g. Math, Science, History"></div>
            <div class="ec-field"><label>Difficulty</label><select name="difficulty" class="ec-select"><?php foreach(array('Easy','Medium','Hard') as $d):?><option value="<?php echo $d;?>" <?php echo($exam?$exam->difficulty:'Medium')===$d?'selected':'';?>><?php echo $d;?></option><?php endforeach;?></select></div>
            <div class="ec-field"><label>Pass Mark (%)</label><input type="number" name="pass_mark" value="<?php echo $exam?(int)$exam->pass_mark:60;?>" min="0" max="100"></div>
            <div class="ec-field"><label>Time Limit (min)</label><input type="number" name="time_limit" value="<?php echo $exam?(int)$exam->time_limit:0;?>" min="0"><div class="ec-hint">0 = no limit</div></div>
            <div class="ec-field"><label>Retake Limit</label><input type="number" name="retake_limit" value="<?php echo $exam&&isset($exam->retake_limit)?(int)$exam->retake_limit:0;?>" min="0"><div class="ec-hint">0 = unlimited</div></div>
            <div class="ec-field"><label>Negative Marking</label><input type="number" name="negative_marking" value="<?php echo $exam&&isset($exam->negative_marking)?floatval($exam->negative_marking):0;?>" min="0" max="1" step="0.25"><div class="ec-hint">Marks deducted per wrong answer</div></div>
            <div class="ec-field"><label>Question Bank (pick N random)</label><input type="number" name="question_bank_count" value="<?php echo $exam&&isset($exam->question_bank_count)?(int)$exam->question_bank_count:0;?>" min="0"><div class="ec-hint">0 = use all</div></div>
            <div class="ec-field" style="padding-top:22px">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0 0 8px"><input type="checkbox" name="randomize_questions" value="1" <?php echo($exam&&!empty($exam->randomize_questions))?'checked':'';?>> Randomize question order</label>
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0"><input type="checkbox" name="randomize_options" value="1" <?php echo($exam&&!empty($exam->randomize_options))?'checked':'';?>> Randomize option order</label>
            </div>
        </div>
        <hr style="border:none;border-top:1px solid #e2e8f0;margin:18px 0">
        <h3 style="font-size:13px;font-weight:800;color:#475569;margin:0 0 12px;text-transform:uppercase;letter-spacing:.05em">📅 Publishing & Resources</h3>
        <div class="ec-grid3">
            <div class="ec-field"><label>Schedule Publish At</label><input type="datetime-local" name="publish_at" value="<?php echo $exam&&$exam->publish_at?date('Y-m-d\TH:i',strtotime($exam->publish_at)):'';?>"><div class="ec-hint">Auto-publishes at this time</div></div>
            <div class="ec-field"><label>Short Notes PDF URL</label><input type="url" name="notes_pdf_url" value="<?php echo esc_attr($exam&&!empty($exam->notes_pdf_url)?$exam->notes_pdf_url:'');?>" placeholder="https://…/notes.pdf"><div class="ec-hint">Study material for students</div></div>
            <div class="ec-field" style="padding-top:22px"><label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0"><input type="checkbox" name="is_published" value="1" <?php echo(!$exam||!empty($exam->is_published))?'checked':'';?>> Published (visible to students)</label></div>
        </div>
        <div style="display:flex;gap:10px;margin-top:18px">
            <button type="submit" class="btn btn-primary btn-lg"><?php echo $is_edit?'💾 Update Exam':'✅ Create Exam';?></button>
            <a href="<?php echo admin_url('admin.php?page=ec');?>" class="btn btn-lg">Cancel</a>
        </div>
    </form>
    </div></div></div>
    <?php
}

/* ══ PAGE: QUESTIONS (multi-tag hint) ══ */
function ec_page_questions(){
    ec_require_admin();
    $eid=absint($_GET['exam_id']??0);$eqid=absint($_GET['edit_q']??0);$msg=sanitize_key($_GET['msg']??'');
    if(!$eid){ec_exam_picker('ec-questions','Manage Questions');return;}
    $exam=ec_exam($eid);if(!$exam){echo '<div class="wrap"><p>Exam not found.</p></div>';return;}
    $qs=ec_questions($eid);$eq=$eqid?ec_question($eqid):null;
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('❓ Questions',esc_html($exam->title).' · '.ec_qcount($eid).' questions','<a href="'.admin_url('admin.php?page=ec-import&exam_id='.$eid).'" class="btn btn-white">📥 Import CSV</a><a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Exams</a>');?>
    <?php ec_notice($msg);?>
    <div class="ec-card" id="ec-qf">
        <div class="ec-ch"><h2 class="ec-ct"><?php echo $eq?'✏️ Edit Question':'➕ Add Question';?></h2><?php if($eq):?><a href="<?php echo admin_url('admin.php?page=ec-questions&exam_id='.$eid);?>" class="btn btn-sm">✕ Cancel</a><?php endif;?></div>
        <div class="ec-cb"><form method="post"><?php ec_nonce();?>
            <input type="hidden" name="ec_action" value="<?php echo $eq?'edit_q':'add_q';?>">
            <input type="hidden" name="exam_id" value="<?php echo $eid;?>">
            <?php if($eq):?><input type="hidden" name="q_id" value="<?php echo(int)$eq->id;?>"><?php endif;?>
            <div class="ec-field"><label>Question <span class="ec-req">*</span></label><textarea name="question" rows="3" required><?php echo esc_textarea($eq?$eq->question:'');?></textarea></div>
            <div class="ec-grid2">
                <?php foreach(array('a'=>'A','b'=>'B','c'=>'C','d'=>'D') as $k=>$lbl):?>
                <div class="ec-field"><label>Option <?php echo $lbl;?> <span class="ec-req">*</span></label><input type="text" name="option_<?php echo $k;?>" required value="<?php echo esc_attr($eq?$eq->{'option_'.$k}:'');?>"></div>
                <?php endforeach;?>
            </div>
            <div class="ec-grid2">
                <div class="ec-field"><label>Correct Answer <span class="ec-req">*</span></label>
                    <input type="text" name="answer" class="ec-select" required value="<?php echo esc_attr($eq?$eq->answer:'A');?>" placeholder="A or A,C for multi" pattern="[A-Da-d](,[A-Da-d])*">
                    <div class="ec-hint">Single: A | Multi: A,C (comma separated, uppercase)</div>
                </div>
                <div class="ec-field"><label>Question Type</label><select name="question_type" class="ec-select"><option value="single" <?php echo($eq&&$eq->question_type==='single')?'selected':'';?>>Single Answer</option><option value="multi" <?php echo($eq&&$eq->question_type==='multi')?'selected':'';?>>Multiple Answers</option></select></div>
                <div class="ec-field"><label>Tag(s) <span class="ec-hint">(comma separated)</span></label><input type="text" name="tag" value="<?php echo esc_attr($eq&&isset($eq->tag)?$eq->tag:'');?>" placeholder="e.g. algebra, equations, functions"></div>
                <div class="ec-field"><label>Question Difficulty</label><select name="q_difficulty" class="ec-select"><?php foreach(array('Easy','Medium','Hard') as $d):?><option value="<?php echo $d;?>" <?php echo($eq&&isset($eq->difficulty)?$eq->difficulty:'Medium')===$d?'selected':'';?>><?php echo $d;?></option><?php endforeach;?></select></div>
                <div class="ec-field"><label>Image URL</label><input type="url" name="image_url" value="<?php echo esc_attr($eq&&isset($eq->image_url)?$eq->image_url:'');?>"></div>
                <div class="ec-field"><label>Sort Order</label><input type="number" name="sort_order" value="<?php echo $eq?(int)$eq->sort_order:0;?>" min="0" style="max-width:90px"></div>
            </div>
            <div class="ec-field"><label>Explanation <span style="font-weight:400;text-transform:none;font-size:11px;color:#94a3b8">(shown after submission — highly recommended)</span></label><textarea name="explanation" rows="3" placeholder="e.g. The answer is A because…"><?php echo esc_textarea($eq?$eq->explanation:'');?></textarea></div>
            <button type="submit" class="btn btn-primary btn-lg"><?php echo $eq?'💾 Update':'✅ Add Question';?></button>
        </form></div>
    </div>
    <?php if($qs):?>
    <div class="ec-card">
        <div class="ec-ch"><h2 class="ec-ct">Question List</h2><span class="pill pill-blue"><?php echo count($qs);?></span></div>
        <table class="ec-tbl">
            <thead><tr><th>#</th><th>Question</th><th>Ans</th><th>Type</th><th>Tag(s)</th><th>Diff</th><th>Expl</th><th>Actions</th></tr></thead>
            <tbody>
            <?php $i=1;foreach($qs as $q):?>
            <tr <?php echo($eq&&$eq->id===$q->id)?'class="ec-edit-row"':'';?>>
                <td style="color:#94a3b8;font-weight:700"><?php echo $i++;?></td>
                <td style="font-weight:600" title="<?php echo esc_attr($q->question);?>"><?php echo esc_html(wp_trim_words($q->question,10));?></td>
                <td><span class="ans-pill"><?php echo esc_html($q->answer);?></span></td>
                <td><span class="pill pill-gray"><?php echo esc_html(isset($q->question_type)?$q->question_type:'single');?></span></td>
                <td style="font-size:11px;color:#64748b"><?php echo esc_html(isset($q->tag)?$q->tag:'');?></td>
                <td><?php $diff=isset($q->difficulty)?$q->difficulty:'Medium';$dc=$diff==='Easy'?'pill-green':($diff==='Hard'?'pill-red':'pill-amber');echo '<span class="pill '.$dc.'">'.esc_html($diff).'</span>';?></td>
                <td><?php echo !empty($q->explanation)?'<span style="color:#16a34a">💡</span>':'—';?></td>
                <td><div style="display:flex;gap:5px">
                    <a href="<?php echo admin_url('admin.php?page=ec-questions&exam_id='.$eid.'&edit_q='.$q->id.'#ec-qf');?>" class="btn btn-sm">✏️</a>
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ec-questions&ec_action=delete_q&q_id='.$q->id),'ec_nonce');?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">🗑</a>
                </div></td>
            </tr>
            <?php endforeach;?>
            </tbody>
        </table>
    </div>
    <?php else:?><div style="background:#f8fafc;border:2px dashed #e2e8f0;border-radius:10px;padding:20px;text-align:center;color:#94a3b8">📭 No questions yet.</div><?php endif;?>
    </div>
    <?php
}

/* ══ PAGE: IMPORT CSV (unchanged) ══ */
function ec_page_import(){
    ec_require_admin();$msg=sanitize_key($_GET['msg']??'');$eid=absint($_GET['exam_id']??0);$exams=ec_exams();
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('📥 Import Questions','Bulk-import from CSV','<a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Back</a>');?>
    <?php ec_notice($msg);?>
    <div class="ec-two">
        <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">📄 CSV Format</h2></div><div class="ec-cb">
            <p style="font-size:13px;margin:0 0 10px">9 columns. Header row skipped automatically.</p>
            <table class="fmt-tbl"><tr><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th><th>7</th><th>8</th><th>9</th></tr>
            <tr><td>Question</td><td>A</td><td>B</td><td>C</td><td>D</td><td>Ans</td><td>Explanation</td><td>Tag</td><td>Difficulty</td></tr>
            </table>
            <pre class="ec-pre" style="margin-top:10px">What is 2+2?,1,3,4,5,C,Basic arithmetic,Math,Easy</pre>
            <div style="margin-top:14px"><a href="<?php echo esc_url(add_query_arg('ec_sample_csv','1',home_url('/')));?>" class="btn">⬇️ Sample CSV</a></div>
        </div></div>
        <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">📤 Upload CSV</h2></div><div class="ec-cb">
            <form method="post" enctype="multipart/form-data"><?php ec_nonce();?>
                <input type="hidden" name="ec_action" value="import_csv">
                <div class="ec-field"><label>Select Exam <span class="ec-req">*</span></label><select name="exam_id" class="ec-select" required><option value="">— Choose —</option><?php foreach($exams as $e):?><option value="<?php echo $e->id;?>" <?php echo $eid==$e->id?'selected':'';?>><?php echo esc_html($e->title);?></option><?php endforeach;?></select></div>
                <div class="ec-field"><label>CSV File <span class="ec-req">*</span></label><input type="file" name="csv_file" accept=".csv" required></div>
                <button type="submit" class="btn btn-primary btn-lg">📥 Import</button>
            </form>
        </div></div>
    </div></div>
    <?php
}

/* ══ PAGE: RESULTS (unchanged) ══ */
function ec_page_results(){
    ec_require_admin();$eid=absint($_GET['exam_id']??0);$msg=sanitize_key($_GET['msg']??'');
    if(!$eid){ec_exam_picker('ec-results','Results');return;}
    $exam=ec_exam($eid);if(!$exam){echo '<div class="wrap"><p>Not found.</p></div>';return;}
    $page=max(1,absint($_GET['paged']??1));$per=20;$total=ec_result_count($eid);$pages=max(1,ceil($total/$per));$results=ec_paged_results($eid,$page,$per);
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('🏆 Results',esc_html($exam->title).' · '.$total.' attempts','<a href="'.admin_url('admin.php?page=ec-analytics&exam_id='.$eid).'" class="btn btn-white">📊 Analytics</a><a href="'.admin_url('admin.php?page=ec-export&exam_id='.$eid).'" class="btn btn-white">📤 Export</a><a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Exams</a>');?>
    <?php ec_notice($msg);?>
    <?php if($results):?>
    <div class="ec-card"><table class="ec-tbl">
        <thead><tr><th>#</th><th>Student</th><th>Score</th><th>%</th><th>Time</th><th>Attempt</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
        <?php $rank=($page-1)*$per;foreach($results as $r):$rank++;$pct=$r->total>0?round($r->score/$r->total*100,1):0;$passed=$pct>=(int)$exam->pass_mark;?>
        <tr>
            <td style="color:#94a3b8;font-weight:700"><?php echo $rank;?></td>
            <td style="font-weight:600"><?php echo esc_html($r->display_name?:'Guest');?></td>
            <td><?php echo number_format($r->score,1).'/'.$r->total;?></td>
            <td><span class="pill <?php echo $passed?'pill-green':'pill-red';?>"><?php echo $pct;?>%</span></td>
            <td><?php echo gmdate('i:s',(int)$r->time_taken);?></td>
            <td><?php echo(int)$r->attempt;?></td>
            <td style="font-size:12px;color:#64748b"><?php echo date('M j, Y',strtotime($r->created_at));?></td>
            <td><form method="post" style="display:inline"><?php ec_nonce();?><input type="hidden" name="ec_action" value="email_result"><input type="hidden" name="result_id" value="<?php echo $r->id;?>"><button type="submit" class="btn btn-sm" onclick="return confirm('Send email to student?')">📧</button></form></td>
        </tr>
        <?php endforeach;?>
        </tbody>
    </table></div>
    <?php if($pages>1):?><div class="ec-pagination"><?php for($i=1;$i<=$pages;$i++):?><?php if($i===$page):?><span class="current"><?php echo $i;?></span><?php else:?><a href="<?php echo admin_url('admin.php?page=ec-results&exam_id='.$eid.'&paged='.$i);?>"><?php echo $i;?></a><?php endif;?><?php endfor;?></div><?php endif;?>
    <?php else:?><div style="background:#f8fafc;border:2px dashed #e2e8f0;border-radius:10px;padding:20px;text-align:center;color:#94a3b8">No results yet.</div><?php endif;?>
    </div>
    <?php
}

/* ══ PAGE: ANALYTICS (unchanged) ══ */
function ec_page_analytics(){
    ec_require_admin();$eid=absint($_GET['exam_id']??0);
    if(!$eid){ec_exam_picker('ec-analytics','Analytics');return;}
    $exam=ec_exam($eid);if(!$exam){echo '<div class="wrap"><p>Not found.</p></div>';return;}
    $a=ec_exam_analytics($eid);
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('📊 Analytics',esc_html($exam->title),'<a href="'.admin_url('admin.php?page=ec-results&exam_id='.$eid).'" class="btn btn-white">🏆 Results</a><a href="'.admin_url('admin.php?page=ec-students').'" class="btn btn-white">👤 Students</a><a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Exams</a>');?>
    <div class="ec-stats">
        <div class="ec-stat"><div class="ec-stat-ico bl">📊</div><div><strong><?php echo $a->total_attempts;?></strong><span>ATTEMPTS</span></div></div>
        <div class="ec-stat"><div class="ec-stat-ico gr">👥</div><div><strong><?php echo $a->unique_users;?></strong><span>STUDENTS</span></div></div>
        <div class="ec-stat"><div class="ec-stat-ico pu">📈</div><div><strong><?php echo round($a->avg_score,1);?>%</strong><span>AVG SCORE</span></div></div>
        <div class="ec-stat"><div class="ec-stat-ico am">⏱</div><div><strong><?php echo gmdate('i:s',(int)$a->avg_time);?></strong><span>AVG TIME</span></div></div>
        <div class="ec-stat"><div class="ec-stat-ico te">✅</div><div><strong><?php echo $a->pass_rate;?>%</strong><span>PASS RATE</span></div></div>
    </div>
    <div class="ec-two">
        <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">Pass / Fail</h2></div><div class="ec-cb" style="text-align:center">
            <div style="display:flex;justify-content:center;gap:30px;margin:10px 0">
                <div><strong style="font-size:28px;color:#16a34a"><?php echo $a->pass_count;?></strong><br><span style="font-size:12px;color:#94a3b8">Passed</span></div>
                <div><strong style="font-size:28px;color:#dc2626"><?php echo $a->fail_count;?></strong><br><span style="font-size:12px;color:#94a3b8">Failed</span></div>
            </div>
            <div style="background:#e2e8f0;border-radius:8px;height:16px;overflow:hidden;margin:8px 0"><div style="background:linear-gradient(90deg,#16a34a,#22c55e);height:100%;width:<?php echo $a->pass_rate;?>%;border-radius:8px"></div></div>
            <span style="font-size:13px;font-weight:700;color:#16a34a"><?php echo $a->pass_rate;?>% Pass Rate</span>
        </div></div>
        <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">Score Distribution</h2></div><div class="ec-cb">
            <?php if($a->dist):$max=1;foreach($a->dist as $d){if($d->cnt>$max)$max=$d->cnt;}?>
            <div class="ec-chart-bar"><?php foreach($a->dist as $d):$h=max(4,round($d->cnt/$max*100));?><div style="height:<?php echo $h;?>%;flex:1"><span><?php echo $d->cnt;?></span><em><?php echo(int)$d->bracket;?>-<?php echo(int)$d->bracket+9;?>%</em></div><?php endforeach;?></div>
            <?php else:?><p style="color:#94a3b8;text-align:center">No data yet</p><?php endif;?>
        </div></div>
    </div>
    <?php if($a->trend&&count($a->trend)>1):?>
    <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">📈 Score Trend Over Time</h2></div><div class="ec-cb">
        <div style="position:relative;height:140px;display:flex;align-items:flex-end;gap:4px">
        <?php foreach($a->trend as $t):$h=round((float)$t->avg_pct);$bh=max(2,$h);$lbl=date('M j',strtotime($t->dt));?>
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;min-width:30px" title="<?php echo $lbl.': '.round($t->avg_pct,1).'%';?>">
            <div style="width:100%;height:<?php echo $bh;?>%;background:linear-gradient(to top,#2563eb,#60a5fa);border-radius:4px 4px 0 0;position:relative"><span style="position:absolute;top:-18px;left:50%;transform:translateX(-50%);font-size:9px;font-weight:700;color:#334155;white-space:nowrap"><?php echo round($t->avg_pct,0);?>%</span></div>
            <span style="font-size:9px;color:#94a3b8;white-space:nowrap"><?php echo $lbl;?></span>
        </div>
        <?php endforeach;?>
        </div>
    </div></div>
    <?php endif;?>
    <?php if($a->tags):?>
    <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">Topic / Tag Performance</h2></div>
        <table class="ec-tbl"><thead><tr><th>Tag</th><th>Attempts</th><th>Avg Score</th><th>Strength Bar</th></tr></thead><tbody>
        <?php foreach($a->tags as $t):$pct=round($t->avg_pct,1);?>
        <tr><td style="font-weight:600"><?php echo esc_html($t->tag);?></td><td><?php echo $t->attempts;?></td><td><span class="pill <?php echo $pct>=60?'pill-green':'pill-red';?>"><?php echo $pct;?>%</span></td><td><div style="background:#e2e8f0;border-radius:4px;height:8px;width:120px;overflow:hidden"><div style="background:<?php echo $pct>=60?'#16a34a':'#dc2626';?>;height:100%;width:<?php echo min(100,$pct);?>%;border-radius:4px"></div></div></td></tr>
        <?php endforeach;?>
        </tbody></table>
    </div>
    <?php endif;?>
    <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">Quick Stats</h2></div><div class="ec-cb"><div class="ec-grid2"><div><strong>Highest Score:</strong> <?php echo number_format($a->highest,1);?></div><div><strong>Lowest Score:</strong> <?php echo number_format($a->lowest,1);?></div></div></div></div>
    </div>
    <?php
}

/* ══ PAGE: STUDENT REPORTS (unchanged) ══ */
function ec_page_students(){
    ec_require_admin();global $wpdb;
    $uid=absint($_GET['user_id']??0);
    $students=$wpdb->get_results("SELECT DISTINCT r.user_id,u.display_name,u.user_email,COUNT(DISTINCT r.exam_id) as exams_taken,COUNT(r.id) as total_attempts,AVG(r.score/r.total*100) as avg_score FROM {$wpdb->prefix}ec_results r LEFT JOIN {$wpdb->users} u ON r.user_id=u.ID WHERE r.user_id>0 GROUP BY r.user_id ORDER BY avg_score DESC");

    if($uid){
        $student=get_userdata($uid);$records=ec_student_analytics($uid);
        $weak=array();foreach(array_unique(array_column($records,'exam_id')) as $eid){$wq=ec_weak_questions($uid,$eid);foreach($wq as $qid=>$cnt){$weak[$qid]=($weak[$qid]??0)+$cnt;}}arsort($weak);
        ?>
        <div class="wrap ec-wrap">
        <?php ec_ph('👤 '.esc_html($student?$student->display_name:'Student'),'Performance Report','<a href="'.admin_url('admin.php?page=ec-students').'" class="btn btn-white">← All Students</a>');?>
        <?php if($records):
            $ta=count($records);$avg=$ta>0?array_sum(array_map(function($r){return $r->total>0?$r->score/$r->total*100:0;},$records))/$ta:0;
            $passes=count(array_filter($records,function($r){return $r->total>0&&($r->score/$r->total*100)>=$r->pass_mark;}));
        ?>
        <div class="ec-stats">
            <div class="ec-stat"><div class="ec-stat-ico bl">📝</div><div><strong><?php echo count(array_unique(array_column($records,'exam_id')));?></strong><span>EXAMS</span></div></div>
            <div class="ec-stat"><div class="ec-stat-ico gr">🔁</div><div><strong><?php echo $ta;?></strong><span>ATTEMPTS</span></div></div>
            <div class="ec-stat"><div class="ec-stat-ico pu">📈</div><div><strong><?php echo round($avg,1);?>%</strong><span>AVG SCORE</span></div></div>
            <div class="ec-stat"><div class="ec-stat-ico am">✅</div><div><strong><?php echo $passes;?></strong><span>PASSED</span></div></div>
        </div>
        <?php if(!empty($weak)):?>
        <div class="ec-card" style="border-left:4px solid #dc2626"><div class="ec-ch"><h2 class="ec-ct">⚠️ Spaced Repetition — Needs Attention</h2></div><div class="ec-cb">
            <?php $shown=0;foreach($weak as $qid=>$cnt){if($shown++>=5)break;$q=ec_question($qid);if(!$q)continue;?>
            <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:12px;margin-bottom:8px">
                <div style="font-size:11px;font-weight:700;color:#dc2626;margin-bottom:4px">Wrong <?php echo $cnt;?>× across attempts</div>
                <div style="font-size:13px;font-weight:600;color:#0f172a"><?php echo esc_html(wp_trim_words($q->question,15));?></div>
                <?php if($q->tag):?><span class="pill pill-gray" style="margin-top:4px"><?php echo esc_html($q->tag);?></span><?php endif;?>
            </div>
            <?php }?>
        </div></div>
        <?php endif;?>
        <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">All Attempts</h2></div>
            <table class="ec-tbl"><thead><tr><th>Exam</th><th>Score</th><th>%</th><th>Status</th><th>Attempt</th><th>Date</th></tr></thead><tbody>
            <?php foreach($records as $r):$pct=$r->total>0?round($r->score/$r->total*100,1):0;$passed=$pct>=$r->pass_mark;?>
            <tr><td style="font-weight:600"><?php echo esc_html($r->exam_title);?></td><td><?php echo number_format($r->score,1).'/'.$r->total;?></td><td><span class="pill <?php echo $passed?'pill-green':'pill-red';?>"><?php echo $pct;?>%</span></td><td><?php echo $passed?'<span class="pill pill-green">Passed</span>':'<span class="pill pill-red">Failed</span>';?></td><td><?php echo $r->attempt;?></td><td style="font-size:12px;color:#64748b"><?php echo date('M j, Y',strtotime($r->created_at));?></td></tr>
            <?php endforeach;?>
            </tbody></table>
        </div>
        <?php else:?><p>No results found.</p><?php endif;?>
        </div>
        <?php return;
    }
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('👤 Student Reports','Per-student performance across all exams');?>
    <?php if($students):?>
    <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">All Students</h2><span class="pill pill-blue"><?php echo count($students);?></span></div>
        <table class="ec-tbl"><thead><tr><th>Student</th><th>Email</th><th>Exams</th><th>Attempts</th><th>Avg Score</th><th>Actions</th></tr></thead><tbody>
        <?php foreach($students as $s):$avg=round((float)$s->avg_score,1);$alert=$avg<50;?>
        <tr <?php echo $alert?'style="background:#fff9f9"':'';?>>
            <td style="font-weight:700"><?php echo esc_html($s->display_name?:'Guest');?> <?php echo $alert?'<span title="Struggling student" style="color:#dc2626">⚠️</span>':'';?></td>
            <td style="font-size:12px;color:#64748b"><?php echo esc_html($s->user_email??'');?></td>
            <td><?php echo $s->exams_taken;?></td>
            <td><?php echo $s->total_attempts;?></td>
            <td><span class="pill <?php echo $avg>=60?'pill-green':'pill-red';?>"><?php echo $avg;?>%</span></td>
            <td><a href="<?php echo admin_url('admin.php?page=ec-students&user_id='.$s->user_id);?>" class="btn btn-sm">📋 Report</a></td>
        </tr>
        <?php endforeach;?>
        </tbody></table>
    </div>
    <?php else:?><div style="background:#f8fafc;border:2px dashed #e2e8f0;border-radius:12px;padding:30px;text-align:center;color:#94a3b8">No student results yet.</div><?php endif;?>
    </div>
    <?php
}

/* ══ PAGE: SCHEDULE (unchanged) ══ */
function ec_page_schedule(){
    ec_require_admin();$msg=sanitize_key($_GET['msg']??'');$exams=ec_exams();$schedules=ec_all_schedules();
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('🗓 Schedule Management','Plan exam dates and sessions','<a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Exams</a>');?>
    <?php ec_notice($msg);?>
    <div class="ec-two">
        <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">➕ Add Schedule Entry</h2></div><div class="ec-cb">
            <form method="post"><?php ec_nonce();?>
                <input type="hidden" name="ec_action" value="save_schedule"><input type="hidden" name="schedule_id" value="0">
                <div class="ec-field"><label>Exam <span class="ec-req">*</span></label><select name="exam_id" class="ec-select" required><option value="">— Choose Exam —</option><?php foreach($exams as $e):?><option value="<?php echo $e->id;?>"><?php echo esc_html($e->title);?></option><?php endforeach;?></select></div>
                <div class="ec-field"><label>Session Title</label><input type="text" name="sched_title" placeholder="e.g. Mid-term Test 1"></div>
                <div class="ec-field"><label>Date <span class="ec-req">*</span></label><input type="date" name="scheduled_date" required value="<?php echo date('Y-m-d');?>"></div>
                <div class="ec-grid2">
                    <div class="ec-field"><label>Start Time</label><input type="time" name="start_time"></div>
                    <div class="ec-field"><label>End Time</label><input type="time" name="end_time"></div>
                </div>
                <div class="ec-field"><label>Note</label><textarea name="note" rows="2" placeholder="e.g. Chapter 1-5, bring notes"></textarea></div>
                <button type="submit" class="btn btn-primary btn-lg">📅 Add to Schedule</button>
            </form>
        </div></div>
        <div class="ec-card"><div class="ec-ch"><h2 class="ec-ct">📅 Schedule Timeline</h2></div><div class="ec-cb">
            <?php if($schedules):$today=date('Y-m-d');?>
            <div class="ec-timeline">
            <?php foreach($schedules as $s):$isPast=$s->scheduled_date<$today;$isToday=$s->scheduled_date===$today;$dc=$isPast?'past':($isToday?'today':'');?>
            <div class="ec-tl-item">
                <div class="ec-tl-dot <?php echo $dc;?>"></div>
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px;<?php echo $isPast?'opacity:.6':'';?>">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
                        <div>
                            <div style="font-size:11px;font-weight:700;color:#64748b;margin-bottom:2px"><?php echo date('D, M j, Y',strtotime($s->scheduled_date));?><?php if($s->start_time):?> · <?php echo substr($s->start_time,0,5);?><?php if($s->end_time):?>–<?php echo substr($s->end_time,0,5);?><?php endif;?><?php endif;?></div>
                            <div style="font-weight:700;color:#0f172a"><?php echo esc_html($s->exam_title);?></div>
                            <?php if($s->title):?><div style="font-size:12px;color:#475569"><?php echo esc_html($s->title);?></div><?php endif;?>
                            <?php if($s->note):?><div style="font-size:11px;color:#94a3b8;margin-top:4px">📝 <?php echo esc_html($s->note);?></div><?php endif;?>
                        </div>
                        <div style="display:flex;flex-direction:column;gap:4px;align-items:flex-end">
                            <?php echo ec_countdown_label($s->scheduled_date);?>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ec-schedule&ec_action=delete_schedule&schedule_id='.$s->id),'ec_nonce');?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">🗑</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach;?>
            </div>
            <?php else:?><div style="text-align:center;color:#94a3b8;padding:20px">No schedule entries yet.</div><?php endif;?>
        </div></div>
    </div></div>
    <?php
}

/* ══ PAGE: CSV EXPORT (unchanged) ══ */
function ec_page_export(){
    ec_require_admin();$eid=absint($_GET['exam_id']??0);
    if(!$eid){ec_exam_picker('ec-export','CSV Export');return;}
    $exam=ec_exam($eid);if(!$exam){echo '<div class="wrap"><p>Not found.</p></div>';return;}
    ?>
    <div class="wrap ec-wrap">
    <?php ec_ph('📤 CSV Export',esc_html($exam->title),'<a href="'.admin_url('admin.php?page=ec').'" class="btn btn-white">← Exams</a>');?>
    <div class="ec-card"><div class="ec-cb" style="text-align:center;padding:30px">
        <p style="margin:0 0 16px;font-size:14px;color:#334155">Export all results for <strong><?php echo esc_html($exam->title);?></strong></p>
        <a href="<?php echo esc_url(add_query_arg(array('ec_csv_export'=>'1','exam_id'=>$eid,'_wpnonce'=>wp_create_nonce('ec_csv_export')),home_url('/')));?>" class="btn btn-primary btn-lg">📤 Download CSV</a>
    </div></div></div>
    <?php
}

/* CSV Export */
add_action('init',function(){
    if(!isset($_GET['ec_csv_export']))return;
    if(!current_user_can('manage_options'))wp_die('No access');
    if(!wp_verify_nonce($_GET['_wpnonce']??'','ec_csv_export'))wp_die('Bad nonce');
    $eid=absint($_GET['exam_id']??0);if(!$eid)wp_die('No exam');
    $results=ec_all_results($eid);
    header('Content-Type: text/csv');header('Content-Disposition: attachment; filename="examcraft-results-'.$eid.'.csv"');
    $out=fopen('php://output','w');fputcsv($out,array('Rank','Student','Email','Score','Total','Percentage','Time (s)','Attempt','Date'));
    $rank=0;foreach($results as $r){$rank++;$user=$r->user_id?get_userdata($r->user_id):null;$pct=$r->total>0?round($r->score/$r->total*100,1):0;fputcsv($out,array($rank,$user?$user->display_name:'Guest',$user?$user->user_email:'',$r->score,$r->total,$pct.'%',$r->time_taken,$r->attempt,$r->created_at));}
    fclose($out);exit;
});

/* Sample CSV */
add_action('init',function(){
    if(!isset($_GET['ec_sample_csv']))return;
    if(!current_user_can('manage_options'))wp_die('No access');
    header('Content-Type: text/csv');header('Content-Disposition: attachment; filename="examcraft-sample.csv"');
    $out=fopen('php://output','w');
    fputcsv($out,array('Question','Option A','Option B','Option C','Option D','Answer','Explanation','Tag','Difficulty'));
    fputcsv($out,array('What is 2+2?','1','3','4','5','C','Basic addition','Math','Easy'));
    fputcsv($out,array('Capital of France?','Berlin','Madrid','Paris','Rome','C','Paris is the capital','Geography','Medium'));
    fclose($out);exit;
});

/* ══ AJAX HANDLERS (add schedule check) ══ */
add_action('wp_ajax_ec_submit','ec_ajax_submit');
function ec_ajax_submit(){
    check_ajax_referer('ec_front_nonce','nonce');
    if(!is_user_logged_in())wp_send_json_error('Login required');
    $uid=get_current_user_id();$eid=absint($_POST['exam_id']??0);$exam=ec_exam($eid);
    if(!$exam)wp_send_json_error('Exam not found');
    $availability = ec_is_exam_available($exam);
    if(!$availability['available']) wp_send_json_error($availability['message']);
    if(!empty($exam->retake_limit)&&$exam->retake_limit>0&&ec_user_attempts($eid,$uid)>=$exam->retake_limit)wp_send_json_error('Retake limit reached');
    $answers=json_decode(stripslashes($_POST['answers']??'{}'),true);
    $time_taken=absint($_POST['time_taken']??0);$qs=ec_questions($eid);$neg=isset($exam->negative_marking)?floatval($exam->negative_marking):0;
    $score=0;$total=count($qs);$details=array();
    foreach($qs as $q){
        $given=isset($answers[$q->id])?sanitize_text_field($answers[$q->id]):'';
        $ca=array_map('trim',explode(',',$q->answer));$ga=array_map('trim',explode(',',$given));sort($ca);sort($ga);
        $ok=($given!==''&&$ca===$ga);
        if($ok)$score+=1;elseif($given!==''&&$neg>0)$score-=$neg;
        $details[]=array('q_id'=>$q->id,'question'=>$q->question,'options'=>array('A'=>$q->option_a,'B'=>$q->option_b,'C'=>$q->option_c,'D'=>$q->option_d),'answer'=>$q->answer,'given'=>$given,'correct'=>$ok,'explanation'=>$q->explanation??'','tag'=>$q->tag??'','difficulty'=>$q->difficulty??'Medium');
    }
    $score=max(0,$score);$attempt=ec_user_attempts($eid,$uid)+1;
    ec_ins_result(array('exam_id'=>$eid,'user_id'=>$uid,'score'=>$score,'total'=>$total,'time_taken'=>$time_taken,'attempt'=>$attempt,'answers_json'=>wp_json_encode($details)));
    $all=ec_all_results($eid);$rank=1;
    foreach($all as $r){if($r->score>$score||($r->score==$score&&$r->time_taken<$time_taken))$rank++;}
    $pct=$total>0?round($score/$total*100,1):0;$passed=$pct>=(int)$exam->pass_mark;
    $tag_perf=array();foreach($details as $d){$tag=$d['tag']?:'General';if(!isset($tag_perf[$tag]))$tag_perf[$tag]=array('correct'=>0,'total'=>0);$tag_perf[$tag]['total']++;if($d['correct'])$tag_perf[$tag]['correct']++;}
    wp_send_json_success(array('score'=>$score,'total'=>$total,'pct'=>$pct,'passed'=>$passed,'pass_mark'=>(int)$exam->pass_mark,'rank'=>$rank,'attempts'=>$attempt,'time_taken'=>$time_taken,'details'=>$details,'tag_perf'=>$tag_perf,'user_name'=>wp_get_current_user()->display_name,'exam_title'=>$exam->title,'notes_pdf'=>$exam->notes_pdf_url??''));
}

add_action('wp_ajax_ec_save_draft','ec_ajax_save_draft');
function ec_ajax_save_draft(){check_ajax_referer('ec_front_nonce','nonce');if(!is_user_logged_in())wp_send_json_error();$uid=get_current_user_id();$eid=absint($_POST['exam_id']??0);$draft_raw=$_POST['draft']??'';$draft_decoded=json_decode(stripslashes($draft_raw),true);if(is_array($draft_decoded)){update_user_meta($uid,'ec_draft_'.$eid,wp_json_encode($draft_decoded));}wp_send_json_success('saved');}

add_action('wp_ajax_ec_clear_draft','ec_ajax_clear_draft');
function ec_ajax_clear_draft(){check_ajax_referer('ec_front_nonce','nonce');if(!is_user_logged_in())wp_send_json_error();delete_user_meta(get_current_user_id(),'ec_draft_'.absint($_POST['exam_id']??0));wp_send_json_success('cleared');}

add_action('wp_ajax_ec_leaderboard','ec_ajax_leaderboard');
add_action('wp_ajax_nopriv_ec_leaderboard','ec_ajax_leaderboard');
function ec_ajax_leaderboard(){
    $eid=absint($_GET['exam_id']??0);if(!$eid)wp_send_json_error();
    $lb=ec_leaderboard($eid,30);$out=array();
    foreach($lb as $i=>$r){$pct=$r->total>0?round($r->score/$r->total*100,1):0;$out[]=array('rank'=>$i+1,'name'=>esc_html($r->display_name?:'Guest'),'score'=>number_format($r->score,1).'/'.$r->total,'pct'=>$pct,'time'=>gmdate('i:s',(int)$r->time_taken));}
    wp_send_json_success($out);
}

/* ══ SHORTCODE [examcraft] with category/tag filters and schedule-aware display ══ */
add_shortcode('examcraft','ec_shortcode');
function ec_shortcode($atts){
    $atts=shortcode_atts(array('id'=>0,'category'=>'','tag'=>''),$atts);
    $eid=absint($atts['id']);
    $category = sanitize_text_field($atts['category']);
    $tag = sanitize_text_field($atts['tag']);
    
    // If ID is provided, show single exam (with availability check)
    if($eid){
        $exam=ec_exam($eid);
        if(!$exam) return '<p>⚠️ Exam not found.</p>';
        $availability = ec_is_exam_available($exam);
        if(!$availability['available']){
            return '<div class="ec-pub" style="text-align:center;padding:30px;background:#f8fafc;border-radius:12px;"><p>'.wp_kses_post($availability['message']).'</p></div>';
        }
        return ec_render_exam($exam);
    }
    
    // Filter by category or tag
    $exams = array();
    if(!empty($category)){
        $exams = ec_get_exams_by_category($category);
    } elseif(!empty($tag)){
        $exams = ec_get_exams_by_tag($tag);
    } else {
        $exams = ec_exams();
    }
    
    if(empty($exams)){
        return '<div class="ec-pub" style="text-align:center;padding:30px;background:#f8fafc;border-radius:12px;"><p>📭 No exams found matching your criteria.</p></div>';
    }
    
    // Display list of exams as cards
    ob_start();
    ?>
    <div class="ec-pub" style="max-width:900px;margin:20px auto;font-family:Inter,sans-serif;">
        <div class="ec-hdr" style="background:linear-gradient(140deg,#1e3a8a,#2563eb);color:#fff;padding:20px 24px;border-radius:12px 12px 0 0;">
            <h2 style="margin:0;font-size:22px;">📚 Available Exams</h2>
            <?php if(!empty($category)) echo '<p style="margin:5px 0 0;opacity:0.8;">Category: '.esc_html($category).'</p>'; ?>
            <?php if(!empty($tag)) echo '<p style="margin:5px 0 0;opacity:0.8;">Tag: '.esc_html($tag).'</p>'; ?>
        </div>
        <div style="background:#fff;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;padding:24px;">
            <?php foreach($exams as $exam):
                $avail = ec_is_exam_available($exam);
                $status_class = $avail['available'] ? 'pill-green' : 'pill-red';
                $status_text = $avail['available'] ? 'Available' : 'Locked';
                ?>
                <div style="border:1px solid #e2e8f0;border-radius:12px;padding:18px;margin-bottom:16px;transition:all 0.2s;">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
                        <div>
                            <h3 style="margin:0 0 6px;font-size:18px;"><?php echo esc_html($exam->title); ?></h3>
                            <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
                                <span class="pill pill-blue"><?php echo esc_html($exam->category ?: 'General'); ?></span>
                                <span class="pill pill-amber"><?php echo esc_html($exam->difficulty); ?></span>
                                <span class="pill pill-green"><?php echo ec_qcount($exam->id); ?> Qs</span>
                                <span class="pill <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                            </div>
                            <?php if($exam->description): ?>
                                <p style="margin:0 0 10px;color:#475569;"><?php echo esc_html(wp_trim_words($exam->description,20)); ?></p>
                            <?php endif; ?>
                            <?php if(!$avail['available']): ?>
                                <div style="background:#fef2f2;border-radius:8px;padding:8px 12px;font-size:13px;color:#dc2626;"><?php echo wp_kses_post($avail['message']); ?></div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php if($avail['available']): ?>
                                <a href="<?php echo esc_url(add_query_arg('ec_exam_id', $exam->id, get_permalink())); ?>" class="btn btn-primary" style="display:inline-block;padding:8px 18px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;border-radius:8px;text-decoration:none;">Start Exam →</a>
                            <?php else: ?>
                                <button class="btn" disabled style="opacity:0.6;cursor:not-allowed;">Locked</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function ec_render_exam($exam){
    $eid=$exam->id;
    $qs=ec_questions($eid);
    if(empty($qs)) return '<p>⚠️ No questions in this exam.</p>';
    if(!empty($exam->question_bank_count)&&$exam->question_bank_count>0&&$exam->question_bank_count<count($qs)){shuffle($qs);$qs=array_slice($qs,0,$exam->question_bank_count);}
    if(!empty($exam->randomize_questions))shuffle($qs);
    if(is_user_logged_in()){$uid=get_current_user_id();$weak=ec_weak_questions($uid,$eid);if(!empty($weak)){$wids=array_keys($weak);usort($qs,function($a,$b)use($wids){$ai=in_array($a->id,$wids)?array_search($a->id,$wids):9999;$bi=in_array($b->id,$wids)?array_search($b->id,$wids):9999;return $ai-$bi;});}}
    if(!empty($exam->randomize_options)){
        foreach($qs as &$q){$opts=array('A'=>$q->option_a,'B'=>$q->option_b,'C'=>$q->option_c,'D'=>$q->option_d);$keys=array_keys($opts);shuffle($keys);$no=array();$am=array();$letters=array('A','B','C','D');foreach($keys as $i=>$ok){$no[$letters[$i]]=$opts[$ok];$am[$ok]=$letters[$i];}$q->option_a=$no['A'];$q->option_b=$no['B'];$q->option_c=$no['C'];$q->option_d=$no['D'];$oa=array_map('trim',explode(',',$q->answer));$na=array();foreach($oa as $o){$na[]=isset($am[$o])?$am[$o]:$o;}$q->answer=implode(',',$na);}unset($q);
    }
    $total=count($qs);$uid=get_current_user_id();$afs=$uid?ec_user_attempts($eid,$uid):0;$rl=isset($exam->retake_limit)?(int)$exam->retake_limit:0;$rb=($rl>0&&$afs>=$rl);
    $ns=ec_get_exam_schedule($eid);
    wp_enqueue_script('jspdf',EC_URL.'assets/js/jspdf.umd.min.js',array(),EC_VER,false);
    ob_start();
    ?>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <style><?php echo ec_css();?></style>
    <div class="ec-pub" id="ec-<?php echo $eid;?>" data-eid="<?php echo $eid;?>" data-nonce="<?php echo wp_create_nonce('ec_front_nonce');?>" data-ajax="<?php echo admin_url('admin-ajax.php');?>" data-logged="<?php echo is_user_logged_in()?'1':'0';?>" data-login="<?php echo wp_login_url(get_permalink());?>" data-pass="<?php echo(int)$exam->pass_mark;?>" data-time="<?php echo(int)$exam->time_limit;?>" data-neg="<?php echo isset($exam->negative_marking)?floatval($exam->negative_marking):0;?>" data-retake-limit="<?php echo $rl;?>" data-attempts="<?php echo $afs;?>" data-retake-blocked="<?php echo $rb?'1':'0';?>">

    <div class="ec-hdr">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px">
            <div><div class="ec-pill quiz">📝 QUIZ MODE</div><div class="ec-pill reading" style="display:none">📖 READING MODE</div></div>
            <button class="ec-dark-btn" onclick="ecToggleDark(this)" style="background:rgba(255,255,255,.18);color:#fff;border:1px solid rgba(255,255,255,.3);padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;cursor:pointer">🌙 Dark Mode</button>
        </div>
        <h2><?php echo esc_html($exam->title);?></h2>
        <?php if($exam->description):?><span class="ec-desc"><?php echo ec_kses($exam->description);?></span><?php endif;?>
        <div class="ec-meta">
            <span>📚 <?php echo $total;?> Qs</span><span>🎯 Pass: <?php echo(int)$exam->pass_mark;?>%</span>
            <?php if($exam->time_limit):?><span>⏱ <?php echo(int)$exam->time_limit;?>m</span><?php endif;?>
            <span>📊 <?php echo esc_html($exam->difficulty);?></span>
            <?php if(!empty($exam->negative_marking)&&$exam->negative_marking>0):?><span>➖ Neg: <?php echo $exam->negative_marking;?></span><?php endif;?>
            <?php if($rl>0):?><span>🔁 <?php echo $afs;?>/<?php echo $rl;?> attempts</span><?php endif;?>
            <?php if(!empty($exam->notes_pdf_url)):?><a href="<?php echo esc_url($exam->notes_pdf_url);?>" target="_blank" style="background:rgba(255,255,255,.17);padding:3px 12px;border-radius:20px;font-size:12px;font-weight:700;color:#fff;text-decoration:none">📄 Notes PDF</a><?php endif;?>
        </div>
        <?php if($ns):$diff=(strtotime($ns->scheduled_date)-strtotime(date('Y-m-d')))/86400;?>
        <div style="margin-top:10px;background:rgba(255,255,255,.12);border-radius:8px;padding:8px 14px;font-size:12px;color:#fff">
            <?php if($diff==0)echo '📅 Scheduled for <strong>Today</strong>';elseif($diff==1)echo '📅 Next session <strong>Tomorrow</strong>';else echo '📅 Next session in <strong>'.(int)$diff.' days</strong> — '.date('M j',strtotime($ns->scheduled_date));if($ns->title)echo ' · '.esc_html($ns->title);?>
        </div>
        <?php endif;?>
    </div>

    <div class="ec-topbar">
        <div class="ec-topbar-l"><span class="ec-qlabel">Q <span class="ec-qcur">1</span>/<span class="ec-qtot"><?php echo $total;?></span></span><span class="ec-acnt"><span class="ec-answered">0</span> answered</span></div>
        <span class="ec-clock" <?php echo !$exam->time_limit?'style="display:none"':'';?>>00:00</span>
    </div>
    <div class="ec-progbar"><div class="ec-progfill" style="width:0%"></div></div>

    <div class="ec-skeleton-wrap" style="background:#fff;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;padding:40px 28px">
        <div style="height:24px;width:60%;background:linear-gradient(90deg,#f1f5f9 25%,#e2e8f0 50%,#f1f5f9 75%);background-size:400% 100%;animation:ec-shimmer 1.5s infinite;border-radius:6px;margin-bottom:16px"></div>
        <?php for($si=0;$si<4;$si++):?><div style="height:52px;width:100%;background:linear-gradient(90deg,#f1f5f9 25%,#e2e8f0 50%,#f1f5f9 75%);background-size:400% 100%;animation:ec-shimmer 1.5s infinite;border-radius:10px;margin-bottom:8px"></div><?php endfor;?>
    </div>
    <style>@keyframes ec-shimmer{0%{background-position:100% 0}100%{background-position:-100% 0}}</style>

    <div class="ec-screen ec-start" style="display:none">
        <div class="ec-start-in">
            <h3>Ready to begin?</h3>
            <p>Answer all <?php echo $total;?> questions. <?php echo $exam->time_limit?'Time limit: '.$exam->time_limit.' minutes.':'No time limit.';?></p>
            <div class="ec-start-stats">
                <div class="ec-ss"><strong><?php echo $total;?></strong><span style="font-size:11px;color:#64748b">Questions</span></div>
                <div class="ec-ss"><strong><?php echo(int)$exam->pass_mark;?>%</strong><span style="font-size:11px;color:#64748b">Pass Mark</span></div>
                <div class="ec-ss"><strong><?php echo $exam->time_limit?$exam->time_limit.'m':'∞';?></strong><span style="font-size:11px;color:#64748b">Time</span></div>
            </div>
            <?php if($rb):?><p style="color:#dc2626;font-weight:700">🔒 Retake limit reached (<?php echo $rl;?> attempts).</p>
            <?php else:?>
            <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
                <button class="ec-btn ec-start-btn">🚀 Start Quiz</button>
                <button class="ec-btn ec-btn-ghost ec-read-btn">📖 Reading Mode</button>
                <button class="ec-btn ec-btn-ghost ec-pdf-btn" data-eid="<?php echo $exam->id;?>" data-title="<?php echo esc_attr($exam->title);?>" data-mode="exam">⬇️ PDF</button>
                <button class="ec-btn ec-btn-ghost ec-board-btn" data-eid="<?php echo $exam->id;?>">🏆 Leaderboard</button>
            </div>
            <?php endif;?>
        </div>
        <div class="ec-lb-section ec-start-lb ec-hidden"><div class="ec-lb-head"><h3>🏆 Leaderboard</h3><button class="ec-lb-close">✕ Close</button></div><div class="ec-lb-body"><div style="text-align:center;padding:20px;color:#64748b">Loading…</div></div></div>
    </div>

    <div class="ec-screen ec-quiz" style="display:none;text-align:left;padding:24px">
        <div class="ec-slides">
        <?php foreach($qs as $i=>$q):$qtype=isset($q->question_type)?$q->question_type:'single';$qdiff=isset($q->difficulty)?$q->difficulty:'Medium';$dc=$qdiff==='Easy'?'#16a34a':($qdiff==='Hard'?'#dc2626':'#d97706');?>
        <div class="ec-slide" data-qid="<?php echo $q->id;?>" data-idx="<?php echo $i;?>" data-type="<?php echo esc_attr($qtype);?>" <?php echo $i>0?'style="display:none"':'';?>>
            <div class="ec-qcard">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                    <div class="ec-qnum">Question <?php echo $i+1;?> of <?php echo $total;?><?php if($qtype==='multi'):?> <span style="font-size:11px;color:#7c3aed;margin-left:6px">(Select multiple)</span><?php endif;?></div>
                    <div style="display:flex;gap:6px;align-items:center">
                        <?php if($q->tag):?><span style="font-size:10px;background:#eff6ff;color:#2563eb;padding:2px 8px;border-radius:12px;font-weight:700"><?php echo esc_html($q->tag);?></span><?php endif;?>
                        <span style="font-size:10px;background:<?php echo $dc;?>22;color:<?php echo $dc;?>;padding:2px 8px;border-radius:12px;font-weight:700"><?php echo esc_html($qdiff);?></span>
                        <button class="ec-bookmark-btn" data-qid="<?php echo $q->id;?>" title="Bookmark" style="background:none;border:none;cursor:pointer;font-size:16px;padding:2px">☆</button>
                    </div>
                </div>
                <?php if(!empty($q->image_url)):?><img src="<?php echo esc_url($q->image_url);?>" alt="" style="max-width:100%;border-radius:8px;margin:8px 0"><?php endif;?>
                <p class="ec-qtext"><?php echo ec_kses($q->question);?></p>
                <div class="ec-opts quiz">
                    <?php foreach(array('A'=>$q->option_a,'B'=>$q->option_b,'C'=>$q->option_c,'D'=>$q->option_d) as $k=>$v):?>
                    <div class="ec-opt quiz" data-opt="<?php echo $k;?>" data-correct="<?php echo esc_attr($q->answer);?>">
                        <span class="ec-lbl"><?php echo $k;?></span><span><?php echo ec_kses($v);?></span><span class="ec-oico"></span>
                    </div>
                    <?php endforeach;?>
                </div>
                <div class="ec-fb" style="display:none"></div>
                <?php if(!empty($q->explanation)):?><div class="ec-expl ec-hidden"><strong style="display:block;margin-bottom:4px;color:#92400e">💡 Explanation</strong><?php echo ec_kses($q->explanation);?></div><?php endif;?>
                <div class="ec-note-area" style="margin-top:10px">
                    <textarea class="ec-note-input" data-qid="<?php echo $q->id;?>" placeholder="📝 Add a note for this question (saved locally)…" style="width:100%;padding:8px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:12px;font-family:inherit;resize:vertical;min-height:40px;background:#fffbeb;display:none"></textarea>
                    <button class="ec-note-toggle" data-qid="<?php echo $q->id;?>" style="font-size:11px;background:none;border:none;color:#94a3b8;cursor:pointer;margin-top:4px;padding:0">📝 Add note</button>
                </div>
            </div>
            <div class="ec-nav-row">
                <button class="ec-btn ec-btn-ghost ec-prev" <?php echo $i===0?'style="visibility:hidden"':'';?>>← Prev</button>
                <?php if($qtype==='multi'):?><button class="ec-btn ec-confirm-multi" style="display:none">Confirm Selection</button><?php endif;?>
                <?php if($i<$total-1):?><button class="ec-btn ec-next">Next →</button><?php else:?><span></span><?php endif;?>
                <button class="ec-btn ec-btn-ghost ec-skip" <?php echo $i>=$total-1?'style="visibility:hidden"':'';?>>Skip</button>
            </div>
        </div>
        <?php endforeach;?>
        </div>
        <div class="ec-nav-panel">
            <div class="ec-nav-panel-head"><strong>📋 Questions</strong><button class="ec-btn ec-btn-ghost ec-submit-mid" style="font-size:12px;padding:6px 14px">✅ Submit Quiz</button></div>
            <div class="ec-nav-grid"><?php for($ni=0;$ni<$total;$ni++):?><button class="ec-nav-dot<?php echo $ni===0?' active':'';?>" data-goto="<?php echo $ni;?>"><?php echo $ni+1;?></button><?php endfor;?></div>
            <div class="ec-bookmarks-panel" style="margin-top:12px;display:none"><div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">⭐ Bookmarked</div><div class="ec-bookmarks-list" style="display:flex;flex-wrap:wrap;gap:4px"></div></div>
        </div>
    </div>

    <div class="ec-screen ec-result" style="display:none">
        <div style="text-align:center">
            <div class="ec-emoji"></div>
            <div class="ec-circle"><svg viewBox="0 0 120 120" width="150" height="150"><circle cx="60" cy="60" r="52" fill="none" stroke="#e5e7eb" stroke-width="12"/><circle cx="60" cy="60" r="52" fill="none" stroke="currentColor" stroke-width="12" stroke-dasharray="326.726" stroke-dashoffset="326.726" class="ec-arc" stroke-linecap="round" transform="rotate(-90 60 60)"/></svg><div class="ec-circle-txt"><div class="ec-pct">0%</div><div class="ec-raw">0/0</div></div></div>
            <div class="ec-stats-row"><div class="ec-sbox"><div>⏱</div><div>Time</div><div class="ec-sv ec-st-time">—</div></div><div class="ec-sbox"><div>🏅</div><div>Rank</div><div class="ec-sv ec-st-rank">—</div></div><div class="ec-sbox"><div>🔁</div><div>Attempts</div><div class="ec-sv ec-st-att">—</div></div><div class="ec-sbox"><div>✅</div><div>Correct</div><div class="ec-sv ec-st-cor">—</div></div></div>
            <div class="ec-verdict"></div>
            <div class="ec-tag-perf" style="display:none;text-align:left;margin:16px 0;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px"><div style="font-size:12px;font-weight:800;color:#475569;text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">📊 Performance by Topic</div><div class="ec-tag-perf-list"></div></div>
            <div style="display:flex;flex-wrap:wrap;gap:10px;justify-content:center">
                <button class="ec-btn ec-review-btn">📋 Review Answers</button>
                <button class="ec-btn ec-btn-ghost ec-board-btn" data-eid="<?php echo $exam->id;?>">🏆 Leaderboard</button>
                <button class="ec-btn ec-btn-ghost ec-pdf-btn" data-eid="<?php echo $exam->id;?>" data-title="<?php echo esc_attr($exam->title);?>" data-mode="result">⬇️ PDF</button>
                <button class="ec-btn ec-btn-ghost ec-retake">🔄 Retake</button>
                <?php if(!empty($exam->notes_pdf_url)):?><a href="<?php echo esc_url($exam->notes_pdf_url);?>" target="_blank" class="ec-btn ec-btn-ghost">📄 Study Notes</a><?php endif;?>
            </div>
        </div>
        <div class="ec-review-panel ec-hidden"><h3>📋 Answer Review</h3><div class="ec-review-list"></div></div>
        <div class="ec-lb-section ec-hidden"><div class="ec-lb-head"><h3>🏆 Leaderboard</h3><button class="ec-lb-close">✕ Close</button></div><div class="ec-lb-body"><div style="text-align:center;padding:20px;color:#64748b">Loading…</div></div></div>
    </div>
    </div>
    <?php
    echo '<script>'.ec_js().'</script>';
    return ob_get_clean();
}

/* ══ FRONTEND CSS (unchanged) ══ */
function ec_css(){return '
@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap&font-display=swap");
.ec-hidden{display:none!important}
.ec-pub{font-family:Inter,system-ui,sans-serif!important;max-width:900px!important;margin:24px auto!important;padding:0 12px!important;box-sizing:border-box!important;transition:background .3s,color .3s}
.ec-pub *,.ec-pub *::before,.ec-pub *::after{box-sizing:border-box!important;font-family:Inter,system-ui,sans-serif!important}
.ec-pub h2,.ec-pub h3,.ec-pub h4{font-family:Inter,system-ui,sans-serif!important;font-weight:800!important;line-height:1.2!important;margin:0!important;padding:0!important;border:none!important;background:none!important}
.ec-pub p{margin:0!important;padding:0!important}
.ec-pub ul,.ec-pub ol{list-style:none!important;padding:0!important;margin:0!important}
.ec-pub li{list-style:none!important;margin:0!important;padding:0!important;background:none!important;border:none!important}
.ec-pub li::before,.ec-pub li::after{display:none!important;content:none!important}
.ec-pub button{font-family:Inter,system-ui,sans-serif!important;cursor:pointer!important}
.ec-hdr{background:linear-gradient(140deg,#1e3a8a 0%,#2563eb 60%,#3b82f6 100%)!important;color:#fff!important;padding:26px 30px!important;border-radius:12px 12px 0 0!important;position:relative!important;overflow:hidden!important;border:none!important}
.ec-hdr h2{font-size:clamp(17px,3vw,25px)!important;font-weight:800!important;margin:7px 0 5px!important;color:#fff!important}
.ec-desc{opacity:.8!important;font-size:14px!important;margin:0 0 8px!important;color:#fff!important;display:block!important}
.ec-meta{display:flex!important;gap:10px!important;flex-wrap:wrap!important}
.ec-meta span,.ec-meta a{background:rgba(255,255,255,.17)!important;padding:3px 12px!important;border-radius:20px!important;font-size:12px!important;font-weight:700!important;color:#fff!important;display:inline-block!important;border:none!important}
.ec-pill{display:inline-block!important;font-size:11px!important;font-weight:700!important;letter-spacing:.07em!important;text-transform:uppercase!important;padding:3px 11px!important;border-radius:20px!important;margin-bottom:7px!important}
.ec-pill.quiz{background:rgba(74,222,128,.28)!important;color:#4ade80!important}
.ec-pill.reading{background:rgba(251,191,36,.28)!important;color:#fbbf24!important}
.ec-topbar{background:#fff!important;border:1px solid #e2e8f0!important;border-top:none!important;padding:9px 18px!important;display:flex!important;justify-content:space-between!important;align-items:center!important;gap:12px!important}
.ec-topbar-l{display:flex!important;gap:14px!important;align-items:center!important}
.ec-qlabel{font-size:13px!important;font-weight:800!important;color:#2563eb!important}
.ec-acnt{font-size:12px!important;color:#64748b!important;font-weight:600!important}
.ec-clock{font-size:13px!important;font-weight:800!important;background:#eff6ff!important;color:#1e40af!important;padding:3px 12px!important;border-radius:20px!important;font-variant-numeric:tabular-nums!important;border:none!important;display:inline-block!important}
.ec-progbar{background:#e2e8f0!important;height:5px!important;display:block!important;border:none!important}
.ec-progfill{background:linear-gradient(90deg,#2563eb,#7c3aed)!important;height:100%!important;transition:width .4s ease!important;display:block!important}
.ec-screen{background:#fff!important;border:1px solid #e2e8f0!important;border-top:none!important;border-radius:0 0 12px 12px!important;padding:40px 28px!important;text-align:center!important}
.ec-result{border-top:1px solid #e2e8f0!important}
.ec-start-in{max-width:420px!important;margin:0 auto!important}
.ec-start-in h3{font-size:21px!important;font-weight:800!important;margin:0 0 7px!important;color:#0f172a!important;display:block!important}
.ec-start-in p{color:#64748b!important;margin:0 0 20px!important;font-size:14px!important;display:block!important}
.ec-start-stats{display:flex!important;justify-content:center!important;gap:14px!important;margin:0 0 24px!important;flex-wrap:wrap!important}
.ec-ss{display:flex!important;flex-direction:column!important;align-items:center!important;background:#f8fafc!important;border:1.5px solid #e2e8f0!important;border-radius:10px!important;padding:12px 18px!important;min-width:80px!important}
.ec-ss strong{font-size:20px!important;font-weight:800!important;color:#2563eb!important;display:block!important;line-height:1!important}
.ec-btn{display:inline-flex!important;align-items:center!important;gap:6px!important;padding:10px 22px!important;border-radius:10px!important;font-size:14px!important;font-weight:700!important;border:none!important;cursor:pointer!important;background:linear-gradient(135deg,#2563eb,#1d4ed8)!important;color:#fff!important;transition:all .2s!important;text-decoration:none!important}
.ec-btn:hover{opacity:.9!important;transform:translateY(-1px)!important}
.ec-btn-ghost{background:#f1f5f9!important;color:#334155!important}
.ec-btn-ghost:hover{background:#e2e8f0!important}
.ec-qcard{background:#f8fafc!important;border:1.5px solid #e2e8f0!important;border-radius:12px!important;padding:22px!important;margin-bottom:14px!important}
.ec-qnum{font-size:12px!important;font-weight:800!important;color:#2563eb!important;letter-spacing:.06em!important;text-transform:uppercase!important}
.ec-qtext{font-size:16px!important;font-weight:700!important;color:#0f172a!important;line-height:1.5!important;margin:0 0 16px!important;display:block!important}
.ec-opts{display:flex!important;flex-direction:column!important;gap:8px!important}
.ec-opt{display:flex!important;align-items:center!important;gap:12px!important;padding:14px 16px!important;border:1.5px solid #e2e8f0!important;border-radius:10px!important;background:#fff!important;cursor:pointer!important;transition:all .2s!important;position:relative!important;min-height:52px!important}
.ec-opt:hover{border-color:#93c5fd!important;background:#eff6ff!important}
.ec-opt.selected{border-color:#2563eb!important;background:#eff6ff!important}
.ec-opt.correct{border-color:#16a34a!important;background:#f0fdf4!important}
.ec-opt.wrong{border-color:#dc2626!important;background:#fef2f2!important}
.ec-opt.disabled{pointer-events:none!important;opacity:.7!important}
.ec-lbl{display:flex!important;align-items:center!important;justify-content:center!important;width:28px!important;height:28px!important;background:#e2e8f0!important;border-radius:8px!important;font-size:13px!important;font-weight:800!important;color:#475569!important;flex-shrink:0!important}
.ec-opt.selected .ec-lbl{background:#2563eb!important;color:#fff!important}
.ec-opt.correct .ec-lbl{background:#16a34a!important;color:#fff!important}
.ec-opt.wrong .ec-lbl{background:#dc2626!important;color:#fff!important}
.ec-oico{margin-left:auto!important;font-size:16px!important;font-weight:800!important;flex-shrink:0!important}
.ec-fb{padding:10px 14px!important;border-radius:8px!important;font-size:13px!important;font-weight:700!important;margin-top:10px!important}
.ec-fb.ok{background:#f0fdf4!important;color:#166534!important;border:1px solid #bbf7d0!important}
.ec-fb.bad{background:#fef2f2!important;color:#991b1b!important;border:1px solid #fecaca!important}
.ec-expl{margin-top:10px!important;padding:12px 14px!important;border-radius:8px!important;background:#fffbeb!important;font-size:13px!important;color:#92400e!important;border:1px solid #fde68a!important;text-align:left!important;line-height:1.5!important}
.ec-nav-row{display:flex!important;justify-content:space-between!important;align-items:center!important;gap:10px!important;margin-top:4px!important;flex-wrap:wrap!important}
.ec-circle{position:relative!important;display:inline-block!important}
.ec-circle-txt{position:absolute!important;top:50%!important;left:50%!important;transform:translate(-50%,-50%)!important;text-align:center!important}
.ec-pct{font-size:24px!important;font-weight:800!important;color:#0f172a!important;line-height:1!important;display:block!important}
.ec-raw{font-size:13px!important;color:#64748b!important;font-weight:600!important}
.ec-stats-row{display:flex!important;justify-content:center!important;gap:10px!important;margin:16px 0!important;flex-wrap:wrap!important}
.ec-sbox{background:#f8fafc!important;border:1.5px solid #e2e8f0!important;border-radius:10px!important;padding:10px 14px!important;text-align:center!important;min-width:70px!important;font-size:11px!important;color:#64748b!important;font-weight:600!important}
.ec-sv{display:block!important;font-size:15px!important;font-weight:800!important;color:#0f172a!important;margin-top:4px!important}
.ec-verdict{padding:8px 24px!important;border-radius:10px!important;font-size:17px!important;font-weight:800!important;display:inline-block!important;margin:10px 0 14px!important}
.ec-review-panel{margin-top:20px!important;text-align:left!important}
.ec-review-panel h3{font-size:16px!important;font-weight:800!important;margin:0 0 12px!important;color:#0f172a!important;display:block!important}
.ec-r-card{background:#f8fafc!important;border:1.5px solid #e2e8f0!important;border-radius:10px!important;padding:14px!important;margin-bottom:10px!important}
.ec-r-card.ok{border-color:#bbf7d0!important;background:#f0fdf4!important}
.ec-r-card.bad{border-color:#fecaca!important;background:#fef2f2!important}
.ec-r-card h4{font-size:13px!important;font-weight:700!important;color:#0f172a!important;margin:0 0 8px!important;display:block!important;line-height:1.4!important}
.ec-r-opts{display:flex!important;flex-direction:column!important;gap:4px!important}
.ec-r-opt{display:flex!important;align-items:center!important;gap:8px!important;padding:6px 10px!important;border-radius:6px!important;font-size:13px!important}
.ec-r-opt.right{background:#f0fdf4!important;font-weight:700!important;color:#166534!important}
.ec-r-opt.wrong-sel{background:#fef2f2!important;font-weight:700!important;color:#991b1b!important}
.ec-r-card .ec-r-expl{margin-top:8px!important;padding:8px 10px!important;border-radius:6px!important;background:#fffbeb!important;font-size:12px!important;color:#92400e!important;border-left:3px solid #fbbf24!important}
.ec-lb-section{margin-top:20px!important;text-align:left!important}
.ec-lb-head{display:flex!important;justify-content:space-between!important;align-items:center!important;margin-bottom:10px!important}
.ec-lb-tbl{width:100%!important;border-collapse:collapse!important;font-size:13px!important}
.ec-lb-tbl th{background:#f8fafc!important;padding:8px 10px!important;text-align:left!important;font-size:11px!important;text-transform:uppercase!important;color:#64748b!important;border-bottom:1px solid #e2e8f0!important}
.ec-lb-tbl td{padding:8px 10px!important;border-bottom:1px solid #f1f5f9!important}
.ec-reading{text-align:left!important;padding:20px!important}
.ec-reading .ec-rq{background:#f8fafc!important;border:1.5px solid #e2e8f0!important;border-radius:10px!important;padding:16px!important;margin-bottom:12px!important;position:relative!important}
.ec-reading .ec-rq-num{font-size:11px!important;font-weight:800!important;color:#2563eb!important;text-transform:uppercase!important;margin-bottom:6px!important}
.ec-reading .ec-rq p{font-size:14px!important;font-weight:700!important;color:#0f172a!important;margin:0 0 10px!important;display:block!important}
.ec-reading .ec-r-opts{display:flex!important;flex-direction:column!important;gap:4px!important}
.ec-reading .ec-r-opt{display:flex!important;align-items:center!important;gap:8px!important;padding:6px 10px!important;border-radius:6px!important;font-size:13px!important}
.ec-reading .ec-r-opt.ans{background:#f0fdf4!important;font-weight:700!important;color:#166534!important}
.ec-highlight{background:#fef08a!important;border-radius:2px!important}
.ec-confirm-multi{background:linear-gradient(135deg,#7c3aed,#6d28d9)!important;color:#fff!important;border:none!important;padding:8px 18px!important;border-radius:8px!important;font-weight:700!important;font-size:13px!important;cursor:pointer!important}
.ec-nav-panel{margin-top:16px!important;background:#fff!important;border:1.5px solid #e2e8f0!important;border-radius:12px!important;padding:14px!important}
.ec-nav-panel-head{display:flex!important;justify-content:space-between!important;align-items:center!important;margin-bottom:10px!important}
.ec-nav-grid{display:flex!important;flex-wrap:wrap!important;gap:6px!important}
.ec-nav-dot{width:34px!important;height:34px!important;border-radius:8px!important;border:1.5px solid #e2e8f0!important;background:#f8fafc!important;font-size:13px!important;font-weight:700!important;color:#475569!important;cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:center!important;transition:all .2s!important}
.ec-nav-dot:hover{border-color:#93c5fd!important;background:#eff6ff!important}
.ec-nav-dot.active{border-color:#2563eb!important;background:#2563eb!important;color:#fff!important}
.ec-nav-dot.done{background:#dcfce7!important;border-color:#86efac!important;color:#166534!important}
.ec-nav-dot.done.active{background:#2563eb!important;color:#fff!important;border-color:#2563eb!important}
.ec-nav-dot.bookmarked{outline:2px solid #f59e0b!important;outline-offset:1px!important}
.ec-inline-msg{display:none;align-items:center!important;justify-content:space-between!important;padding:10px 16px!important;border-radius:10px!important;font-size:13px!important;font-weight:600!important;margin-bottom:10px!important;gap:10px!important}
.ec-inline-msg button{background:none!important;border:none!important;font-size:16px!important;cursor:pointer!important;color:inherit!important;padding:0!important}
.ec-msg-error{background:#fef2f2!important;color:#991b1b!important;border:1px solid #fecaca!important}
.ec-msg-info{background:#eff6ff!important;color:#1e40af!important;border:1px solid #bfdbfe!important}
.ec-msg-success{background:#f0fdf4!important;color:#166534!important;border:1px solid #bbf7d0!important}
.ec-confirm-submit{position:fixed!important;top:0!important;left:0!important;right:0!important;bottom:0!important;background:rgba(0,0,0,0.4)!important;display:flex!important;align-items:center!important;justify-content:center!important;z-index:9999!important}
.ec-confirm-box{background:#fff!important;border-radius:12px!important;padding:24px!important;max-width:400px!important;width:90%!important;text-align:center!important;box-shadow:0 20px 60px rgba(0,0,0,0.2)!important}
.ec-confirm-box p{font-size:15px!important;color:#334155!important;margin:0 0 16px!important}
.ec-qtext table{width:100%!important;border-collapse:collapse!important;margin:10px 0!important;font-size:14px!important}
.ec-qtext table th,.ec-qtext table td{border:1px solid #e2e8f0!important;padding:6px 10px!important;text-align:left!important}
.ec-qtext table th{background:#f1f5f9!important;font-weight:700!important}
.ec-qtext p{margin:6px 0!important}
.ec-pub.ec-dark{background:#0f172a!important;color:#e2e8f0!important}
.ec-pub.ec-dark .ec-topbar{background:#1e293b!important;border-color:#334155!important}
.ec-pub.ec-dark .ec-clock{background:#1e3a5f!important;color:#93c5fd!important}
.ec-pub.ec-dark .ec-screen{background:#1e293b!important;border-color:#334155!important;color:#e2e8f0!important}
.ec-pub.ec-dark .ec-qcard{background:#0f172a!important;border-color:#334155!important}
.ec-pub.ec-dark .ec-qtext{color:#f1f5f9!important}
.ec-pub.ec-dark .ec-opt{background:#1e293b!important;border-color:#334155!important}
.ec-pub.ec-dark .ec-opt:hover{background:#1e3a5f!important;border-color:#60a5fa!important}
.ec-pub.ec-dark .ec-nav-panel{background:#1e293b!important;border-color:#334155!important}
.ec-pub.ec-dark .ec-nav-dot{background:#334155!important;border-color:#475569!important;color:#cbd5e1!important}
.ec-pub.ec-dark .ec-r-card{background:#1e293b!important;border-color:#334155!important}
.ec-pub.ec-dark .ec-ss{background:#1e293b!important;border-color:#334155!important}
@media(max-width:600px){
.ec-hdr{padding:18px!important}
.ec-screen{padding:20px 14px!important}
.ec-qcard{padding:14px!important}
.ec-stats-row{gap:6px!important}
.ec-sbox{padding:8px 10px!important;min-width:60px!important}
.ec-nav-dot{width:36px!important;height:36px!important;font-size:13px!important}
.ec-opt{padding:14px 12px!important;min-height:56px!important}
.ec-btn{padding:12px 20px!important;font-size:14px!important}
}
';}

/* ══ FRONTEND JS (unchanged, but already includes PDF generation fixes) ══ */
function ec_js(){return '
(function(){
"use strict";
window.ecToggleDark=function(btn){document.querySelectorAll(".ec-pub").forEach(function(p){p.classList.toggle("ec-dark");});var d=document.querySelector(".ec-pub").classList.contains("ec-dark");btn.textContent=d?"☀️ Light Mode":"🌙 Dark Mode";try{localStorage.setItem("ec_dark",d?"1":"0");}catch(e){}};
try{if(localStorage.getItem("ec_dark")==="1"){document.querySelectorAll(".ec-pub").forEach(function(p){p.classList.add("ec-dark");});document.querySelectorAll(".ec-dark-btn").forEach(function(b){b.textContent="☀️ Light Mode";});}}catch(e){}

document.querySelectorAll(".ec-pub").forEach(function(root){
var eid=root.dataset.eid,nonce=root.dataset.nonce,ajax=root.dataset.ajax;
var logged=root.dataset.logged==="1",loginUrl=root.dataset.login;
var passMark=parseInt(root.dataset.pass)||60,timeLimit=parseInt(root.dataset.time)||0,negMark=parseFloat(root.dataset.neg)||0;
var retakeLimit=parseInt(root.dataset.retakeLimit)||0,attemptsSoFar=parseInt(root.dataset.attempts)||0,retakeBlocked=root.dataset.retakeBlocked==="1";
var answers={},elapsed=0,timer=null,submitted=false,resultData=null;
var slides=root.querySelectorAll(".ec-slide"),total=slides.length,cur=0,answered=0;
var SAVE_KEY="ec_progress_"+eid,bookmarks=new Set(),notes={};
var $=function(s){return root.querySelector(s)};
setTimeout(function(){var sk=root.querySelector(".ec-skeleton-wrap");if(sk)sk.style.display="none";var st=$(".ec-start");if(st)st.style.display="block";},400);
function ecMsg(text,type){var box=root.querySelector(".ec-inline-msg");if(!box){box=document.createElement("div");box.className="ec-inline-msg";root.prepend(box);}box.innerHTML="";var sp=document.createElement("span");sp.textContent=text;box.appendChild(sp);var cl=document.createElement("button");cl.className="ec-msg-close";cl.textContent="✕";box.appendChild(cl);box.className="ec-inline-msg ec-msg-"+type;box.style.display="flex";box.querySelector(".ec-msg-close").onclick=function(){box.style.display="none";};if(type!=="error")setTimeout(function(){box.style.display="none";},5000);}
function saveProgress(){var data={answers:answers,cur:cur,elapsed:elapsed,answered:answered,notes:notes};try{localStorage.setItem(SAVE_KEY,JSON.stringify(data));}catch(e){}if(logged&&elapsed%30===0){var fd=new FormData();fd.append("action","ec_save_draft");fd.append("nonce",nonce);fd.append("exam_id",eid);fd.append("draft",JSON.stringify(data));fetch(ajax,{method:"POST",body:fd,credentials:"same-origin"}).catch(function(){});}}
function loadProgress(){try{var local=localStorage.getItem(SAVE_KEY);if(local){var d=JSON.parse(local);if(d&&d.answers){applyProgress(d);return true;}}}catch(e){}return false;}
function applyProgress(d){if(!d||!d.answers)return;answers=d.answers;cur=d.cur||0;elapsed=d.elapsed||0;answered=d.answered||0;notes=d.notes||{};slides.forEach(function(sl){var qid=sl.dataset.qid;if(answers[qid]){var gv=answers[qid].split(",");sl.querySelectorAll(".ec-opt").forEach(function(opt){if(gv.indexOf(opt.dataset.opt)>-1)opt.classList.add("selected");});}if(notes[qid]){var ta=sl.querySelector(".ec-note-input");if(ta){ta.value=notes[qid];ta.style.display="block";}var tb=sl.querySelector(".ec-note-toggle");if(tb)tb.textContent="📝 Edit note";}});}
function clearProgress(){try{localStorage.removeItem(SAVE_KEY);}catch(e){}if(logged){var fd=new FormData();fd.append("action","ec_clear_draft");fd.append("nonce",nonce);fd.append("exam_id",eid);fetch(ajax,{method:"POST",body:fd,credentials:"same-origin"}).catch(function(){});}}
function fmtT(s){var m=Math.floor(s/60),ss=s%60;return String(m).padStart(2,"0")+":"+String(ss).padStart(2,"0");}
function startTimer(){var cl=$(".ec-clock");if(timeLimit){var rem=timeLimit*60-elapsed;cl.textContent=fmtT(Math.max(0,rem));}timer=setInterval(function(){elapsed++;if(timeLimit){var rem=timeLimit*60-elapsed;if(rem<=0){clearInterval(timer);submitQuiz();return;}cl.textContent=fmtT(rem);if(rem<=30)cl.style.cssText+="background:#fef2f2!important;color:#dc2626!important";}else{cl.style.display="inline-block";cl.textContent=fmtT(elapsed);}if(elapsed%5===0)saveProgress();},1000);}
function refreshBookmarksPanel(){var p=root.querySelector(".ec-bookmarks-panel"),l=root.querySelector(".ec-bookmarks-list");if(!p||!l)return;if(bookmarks.size===0){p.style.display="none";return;}p.style.display="block";l.innerHTML="";bookmarks.forEach(function(qid){var sl=root.querySelector(".ec-slide[data-qid=\""+qid+"\"]");if(!sl)return;var idx=parseInt(sl.dataset.idx);var d=document.createElement("button");d.textContent=idx+1;d.style.cssText="width:32px;height:32px;border-radius:8px;border:2px solid #f59e0b;background:#fffbeb;color:#92400e;font-weight:700;font-size:12px;cursor:pointer";d.onclick=function(){showSlide(idx);};l.appendChild(d);});}
root.addEventListener("click",function(e){var btn=e.target.closest(".ec-bookmark-btn");if(!btn)return;var qid=btn.dataset.qid;if(bookmarks.has(qid))bookmarks.delete(qid);else bookmarks.add(qid);btn.textContent=bookmarks.has(qid)?"⭐":"☆";btn.style.color=bookmarks.has(qid)?"#f59e0b":"#94a3b8";var sl=root.querySelector(".ec-slide[data-qid=\""+qid+"\"]");if(sl){var nd=root.querySelectorAll(".ec-nav-dot")[parseInt(sl.dataset.idx)];if(nd){if(bookmarks.has(qid))nd.classList.add("bookmarked");else nd.classList.remove("bookmarked");}}refreshBookmarksPanel();});
root.addEventListener("click",function(e){var btn=e.target.closest(".ec-note-toggle");if(!btn)return;var ta=btn.closest(".ec-note-area").querySelector(".ec-note-input");if(ta.style.display==="none"||!ta.style.display){ta.style.display="block";ta.focus();btn.textContent="📝 Hide note";}else{ta.style.display="none";btn.textContent=ta.value?"📝 Edit note":"📝 Add note";}});
root.addEventListener("input",function(e){var ta=e.target.closest(".ec-note-input");if(!ta)return;notes[ta.dataset.qid]=ta.value;saveProgress();});
function showSlide(idx){slides.forEach(function(s,i){s.style.display=i===idx?"":"none";});cur=idx;var ql=$(".ec-qcur");if(ql)ql.textContent=idx+1;var pf=$(".ec-progfill");if(pf)pf.style.width=(answered/total*100)+"%";var ac=$(".ec-answered");if(ac)ac.textContent=answered;root.querySelectorAll(".ec-nav-dot").forEach(function(dot,di){dot.classList.remove("active");if(di===idx)dot.classList.add("active");if(slides[di]&&answers[slides[di].dataset.qid])dot.classList.add("done");});if(window.innerWidth<600)root.scrollIntoView({behavior:"smooth",block:"start"});saveProgress();}
root.addEventListener("click",function(e){
var t=e.target.closest(".ec-prev");if(t&&cur>0){showSlide(cur-1);return;}
t=e.target.closest(".ec-next");if(t&&cur<total-1){showSlide(cur+1);return;}
t=e.target.closest(".ec-skip");if(t&&cur<total-1){showSlide(cur+1);return;}
t=e.target.closest(".ec-nav-dot");if(t){var gi=parseInt(t.dataset.goto);if(!isNaN(gi)&&gi>=0&&gi<total)showSlide(gi);return;}
t=e.target.closest(".ec-submit-mid");if(t&&!submitted){var ua=total-Object.keys(answers).length;if(ua>0){var conf=root.querySelector(".ec-confirm-submit");if(!conf){conf=document.createElement("div");conf.className="ec-confirm-submit";var bx=document.createElement("div");bx.className="ec-confirm-box";var pp=document.createElement("p");pp.innerHTML="\u26a0\ufe0f <strong>"+ua+"</strong> unanswered question(s). Submit anyway?";var br=document.createElement("div");br.style.cssText="display:flex;gap:8px;justify-content:center";var yb=document.createElement("button");yb.className="ec-btn ec-do-submit";yb.textContent="Yes, Submit";var cb=document.createElement("button");cb.className="ec-btn ec-btn-ghost ec-cancel-submit";cb.textContent="Cancel";br.appendChild(yb);br.appendChild(cb);bx.appendChild(pp);bx.appendChild(br);conf.appendChild(bx);root.appendChild(conf);}else{conf.querySelector("p").innerHTML="\u26a0\ufe0f <strong>"+ua+"</strong> unanswered. Submit anyway?";conf.style.display="flex";}}else submitQuiz();return;}
t=e.target.closest(".ec-do-submit");if(t){var cs=root.querySelector(".ec-confirm-submit");if(cs)cs.remove();submitQuiz();return;}
t=e.target.closest(".ec-cancel-submit");if(t){var cs2=root.querySelector(".ec-confirm-submit");if(cs2)cs2.remove();return;}
});
root.addEventListener("click",function(e){var opt=e.target.closest(".ec-opt.quiz");if(!opt||opt.classList.contains("disabled")||submitted)return;var slide=opt.closest(".ec-slide"),qtype=slide.dataset.type||"single",qid=slide.dataset.qid;
if(qtype==="multi"){opt.classList.toggle("selected");var sel=[];slide.querySelectorAll(".ec-opt.selected").forEach(function(o){sel.push(o.dataset.opt);});var cfb=slide.querySelector(".ec-confirm-multi");if(cfb)cfb.style.display=sel.length>0?"inline-flex":"none";if(sel.length>0)answers[qid]=sel.sort().join(",");else delete answers[qid];saveProgress();return;}
if(answers[qid])return;
var chosen=opt.dataset.opt,correctStr=opt.dataset.correct,corrects=correctStr.split(",").map(function(s){return s.trim();});
answers[qid]=chosen;answered++;
slide.querySelectorAll(".ec-opt").forEach(function(o){o.classList.add("disabled");if(corrects.indexOf(o.dataset.opt)>-1){o.classList.add("correct");o.querySelector(".ec-oico").textContent="✓";}if(o.dataset.opt===chosen&&corrects.indexOf(chosen)===-1){o.classList.add("wrong");o.querySelector(".ec-oico").textContent="✗";}});
var fb=slide.querySelector(".ec-fb"),isCorrect=corrects.indexOf(chosen)>-1;
if(fb){fb.style.display="block";fb.className="ec-fb "+(isCorrect?"ok":"bad");fb.textContent=isCorrect?"✅ Correct!":"❌ Wrong — correct: "+corrects.join(", ");}
var expl=slide.querySelector(".ec-expl");if(expl)expl.classList.remove("ec-hidden");
showSlide(cur);saveProgress();
if(cur<total-1)setTimeout(function(){if(!submitted)showSlide(cur+1);},1200);else if(answered>=total)setTimeout(function(){submitQuiz();},1500);
});
root.addEventListener("click",function(e){var btn=e.target.closest(".ec-confirm-multi");if(!btn||btn.disabled)return;var slide=btn.closest(".ec-slide"),qid=slide.dataset.qid;if(!answers[qid])return;btn.disabled=true;var cs=slide.querySelector(".ec-opt").dataset.correct,corrects=cs.split(",").map(function(s){return s.trim();}).sort(),given=answers[qid].split(",").sort(),isCorrect=corrects.join(",")===given.join(",");answered++;slide.querySelectorAll(".ec-opt").forEach(function(o){o.classList.add("disabled");if(corrects.indexOf(o.dataset.opt)>-1){o.classList.add("correct");o.querySelector(".ec-oico").textContent="✓";}if(given.indexOf(o.dataset.opt)>-1&&corrects.indexOf(o.dataset.opt)===-1){o.classList.add("wrong");o.querySelector(".ec-oico").textContent="✗";}});btn.style.display="none";var fb=slide.querySelector(".ec-fb");if(fb){fb.style.display="block";fb.className="ec-fb "+(isCorrect?"ok":"bad");fb.textContent=isCorrect?"✅ Correct!":"❌ Wrong — correct: "+corrects.join(", ");}var expl=slide.querySelector(".ec-expl");if(expl)expl.classList.remove("ec-hidden");showSlide(cur);saveProgress();if(cur<total-1)setTimeout(function(){if(!submitted)showSlide(cur+1);},1200);else if(answered>=total)setTimeout(function(){submitQuiz();},1500);});
document.addEventListener("keydown",function(e){if(submitted)return;var qs=$(".ec-quiz");if(!qs||qs.style.display==="none")return;var k=e.key.toUpperCase();if(["A","B","C","D"].indexOf(k)>-1){var opt=slides[cur].querySelector(".ec-opt[data-opt=\""+k+"\"]");if(opt&&!opt.classList.contains("disabled"))opt.click();e.preventDefault();}if(e.key==="ArrowRight"||e.key==="Enter"){var nb=slides[cur].querySelector(".ec-next");if(nb)nb.click();e.preventDefault();}if(e.key==="ArrowLeft"){var pb=slides[cur].querySelector(".ec-prev");if(pb)pb.click();e.preventDefault();}});
function submitQuiz(){if(submitted)return;submitted=true;if(timer)clearInterval(timer);if(!logged){ecMsg("Please log in to save your result. Redirecting...","error");setTimeout(function(){window.location.href=loginUrl;},2000);return;}var sb=$(".ec-submit-mid");if(sb){sb.textContent="⏳ Submitting…";sb.disabled=true;}var fd=new FormData();fd.append("action","ec_submit");fd.append("nonce",nonce);fd.append("exam_id",eid);fd.append("answers",JSON.stringify(answers));fd.append("time_taken",elapsed);fetch(ajax,{method:"POST",body:fd,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(r){if(!r.success){ecMsg(r.data||"Error","error");submitted=false;if(sb){sb.textContent="✅ Submit Quiz";sb.disabled=false;}return;}resultData=r.data;clearProgress();showResult(r.data);}).catch(function(){ecMsg("Network error — please check your connection and try again.","error");submitted=false;if(sb){sb.textContent="✅ Submit Quiz";sb.disabled=false;}});}
function showResult(d){var csm=root.querySelector(".ec-confirm-submit");if(csm)csm.remove();$(".ec-start").style.display="none";$(".ec-quiz").style.display="none";$(".ec-topbar").style.display="none";$(".ec-progbar").style.display="none";$(".ec-result").style.display="block";var qp=root.querySelector(".ec-pill.quiz");if(qp)qp.style.display="none";var color=d.passed?"#16a34a":"#dc2626";root.querySelector(".ec-arc").style.stroke=color;$(".ec-emoji").textContent=d.passed?"🎉":"😔";$(".ec-pct").textContent=d.pct+"%";$(".ec-raw").textContent=d.score+"/"+d.total;$(".ec-st-time").textContent=fmtT(d.time_taken);$(".ec-st-rank").textContent="#"+d.rank;$(".ec-st-att").textContent=d.attempts;$(".ec-st-cor").textContent=Math.round(d.score)+"/"+d.total;var v=$(".ec-verdict");if(d.passed){v.style.cssText="background:#f0fdf4!important;color:#16a34a!important";v.textContent="🎉 PASSED!";}else{v.style.cssText="background:#fef2f2!important;color:#dc2626!important";v.textContent="😔 Not Passed";}var arc=root.querySelector(".ec-arc"),target=326.726*(1-d.pct/100);setTimeout(function(){arc.style.transition="stroke-dashoffset 1.5s ease";arc.style.strokeDashoffset=target;},100);
if(d.tag_perf&&Object.keys(d.tag_perf).length>0){var tp=$(".ec-tag-perf"),tl=$(".ec-tag-perf-list");if(tp&&tl){tl.innerHTML="";Object.keys(d.tag_perf).forEach(function(tag){var t=d.tag_perf[tag],pct=t.total>0?Math.round(t.correct/t.total*100):0,col=pct>=60?"#16a34a":"#dc2626";tl.innerHTML+="<div style=\"margin-bottom:8px\"><div style=\"display:flex;justify-content:space-between;font-size:12px;font-weight:700;margin-bottom:3px\"><span>"+tag+"</span><span style=\"color:"+col+"\">"+pct+"%</span></div><div style=\"background:#e2e8f0;border-radius:4px;height:6px;overflow:hidden\"><div style=\"background:"+col+";height:100%;width:"+pct+"%\"></div></div></div>";});tp.style.display="block";}}
var rl=$(".ec-review-list");rl.innerHTML="";(d.details||[]).forEach(function(r,i){var cls=r.correct?"ok":(!r.given?"skip":"bad"),icon=r.correct?"✅":(!r.given?"⏭":"❌");var card=document.createElement("div");card.className="ec-r-card "+cls;var h="<h4>"+icon+" Q"+(i+1)+": "+ecClean(r.question)+"</h4><div class=\"ec-r-opts\">";["A","B","C","D"].forEach(function(k){var corrects=(r.answer||"").split(",").map(function(s){return s.trim();}),givens=(r.given||"").split(",").map(function(s){return s.trim();});var c="ec-r-opt";if(corrects.indexOf(k)>-1)c+=" right";if(givens.indexOf(k)>-1&&corrects.indexOf(k)===-1)c+=" wrong-sel";var mark="";if(corrects.indexOf(k)>-1)mark=" ✓";if(givens.indexOf(k)>-1&&corrects.indexOf(k)===-1)mark=" ✗";h+="<div class=\""+c+"\"><strong>"+k+".</strong> "+ecClean(r.options[k]||"")+mark+"</div>";});h+="</div>";if(r.explanation)h+="<div class=\"ec-r-expl\"><strong>💡 Explanation:</strong> "+ecClean(r.explanation)+"</div>";card.innerHTML=h;rl.appendChild(card);});}
root.addEventListener("click",function(e){var b=e.target.closest(".ec-board-btn");if(!b)return;var screens=root.querySelectorAll(".ec-screen"),vs=null;screens.forEach(function(s){if(s.style.display!=="none"&&!s.classList.contains("ec-hidden"))vs=s;});var sec=vs?vs.querySelector(".ec-lb-section"):root.querySelector(".ec-lb-section");if(!sec)sec=root.querySelector(".ec-lb-section");if(sec){sec.classList.toggle("ec-hidden");if(!sec.classList.contains("ec-hidden"))fetchLB(sec.querySelector(".ec-lb-body"));}});
root.addEventListener("click",function(e){if(e.target.closest(".ec-lb-close"))root.querySelectorAll(".ec-lb-section").forEach(function(s){s.classList.add("ec-hidden");});});
function fetchLB(container){fetch(ajax+"?action=ec_leaderboard&exam_id="+eid).then(function(r){return r.json();}).then(function(r){if(!r.success){container.innerHTML="<p>Error</p>";return;}var h="<table class=\"ec-lb-tbl\"><thead><tr><th>#</th><th>Name</th><th>Score</th><th>%</th><th>Time</th></tr></thead><tbody>";r.data.forEach(function(e){h+="<tr><td>"+e.rank+"</td><td>"+e.name+"</td><td>"+e.score+"</td><td>"+e.pct+"%</td><td>"+e.time+"</td></tr>";});h+="</tbody></table>";container.innerHTML=h;});}
root.addEventListener("click",function(e){if(!e.target.closest(".ec-retake"))return;if(retakeLimit>0){var na=resultData?resultData.attempts:attemptsSoFar+1;if(na>=retakeLimit){ecMsg("You have reached the maximum retake limit ("+retakeLimit+").","error");return;}}location.reload();});
root.addEventListener("click",function(e){if(!e.target.closest(".ec-start-btn"))return;if(!logged){ecMsg("Please log in first. Redirecting...","error");setTimeout(function(){window.location.href=loginUrl;},2000);return;}$(".ec-start").style.display="none";$(".ec-quiz").style.display="block";var restored=loadProgress();if(restored&&Object.keys(answers).length>0)showSlide(cur);startTimer();});
root.addEventListener("click",function(e){if(e.target.closest(".ec-review-btn")){var p=$(".ec-review-panel");p.classList.toggle("ec-hidden");}});
root.addEventListener("click",function(e){if(!e.target.closest(".ec-read-btn"))return;$(".ec-start").style.display="none";root.querySelector(".ec-pill.quiz").style.display="none";root.querySelector(".ec-pill.reading").style.display="inline-block";var screen=document.createElement("div");screen.className="ec-screen ec-reading";var tb=document.createElement("div");tb.style.cssText="display:flex;gap:8px;margin-bottom:16px;align-items:center;flex-wrap:wrap";tb.innerHTML="<strong style=\"font-size:12px;color:#64748b\">🖍 Select text to highlight</strong><button onclick=\"ecClearHighlights()\" style=\"font-size:11px;background:#f1f5f9;border:1px solid #e2e8f0;border-radius:6px;padding:3px 10px;cursor:pointer\">Clear Highlights</button>";screen.appendChild(tb);slides.forEach(function(sl,i){var q=sl.querySelector(".ec-qtext").innerHTML,opts=sl.querySelectorAll(".ec-opt"),correct=(opts[0]?opts[0].dataset.correct:"A"),corrects=correct.split(",").map(function(s){return s.trim();});var div=document.createElement("div");div.className="ec-rq";div.innerHTML="<div class=\"ec-rq-num\">Question "+(i+1)+"</div><p>"+q+"</p><div class=\"ec-r-opts\">"+Array.from(opts).map(function(o){var k=o.dataset.opt,isAns=corrects.indexOf(k)>-1;return"<div class=\"ec-r-opt"+(isAns?" ans":"")+"\"><strong>"+k+".</strong> "+o.querySelector("span:nth-child(2)").innerHTML+(isAns?" ✓":"")+"</div>";}).join("")+"</div>";var expl=sl.querySelector(".ec-expl");if(expl){var ed=document.createElement("div");ed.style.cssText="margin-top:10px;padding:10px 12px;border-radius:8px;background:#fffbeb;font-size:12px;color:#92400e;border:1px solid #fde68a;border-left:3px solid #fbbf24";ed.innerHTML="<strong>💡 Explanation:</strong> "+expl.innerHTML;div.appendChild(ed);}if(bookmarks.has(sl.dataset.qid)){var bm=document.createElement("span");bm.textContent="⭐";bm.style.cssText="position:absolute;top:12px;right:12px;font-size:14px";div.style.position="relative";div.appendChild(bm);}screen.appendChild(div);});var footer=document.createElement("div");footer.style.cssText="text-align:center;margin-top:16px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap";footer.innerHTML="<button class=\"ec-btn ec-btn-ghost\" onclick=\"location.reload()\">← Back to Start</button><button class=\"ec-btn ec-pdf-btn\" data-eid=\""+eid+"\" data-title=\""+root.querySelector(".ec-hdr h2").textContent+"\" data-mode=\"exam\">⬇️ Download PDF</button>";screen.appendChild(footer);root.querySelector(".ec-result").insertAdjacentElement("beforebegin",screen);screen.addEventListener("mouseup",function(){var sel=window.getSelection();if(!sel||sel.isCollapsed||!sel.rangeCount)return;var range=sel.getRangeAt(0);if(!screen.contains(range.commonAncestorContainer))return;try{var mark=document.createElement("mark");mark.className="ec-highlight";range.surroundContents(mark);sel.removeAllRanges();}catch(err){}});});
window.ecClearHighlights=function(){document.querySelectorAll(".ec-highlight").forEach(function(m){var p=m.parentNode;while(m.firstChild)p.insertBefore(m.firstChild,m);p.removeChild(m);});};
function ecClean(str){if(!str)return"";var ta=document.createElement("textarea");ta.innerHTML=str;var t=ta.value;t=t.replace(/<br\s*\/?>/gi,"\n");t=t.replace(/<[^>]+>/g,"");return t;}
window.ecCleanText=ecClean;
var EC_WM="ExamCraft",EC_M=14;
function fmtL(s){return String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0");}
root.addEventListener("click",function(e){var btn=e.target.closest(".ec-pdf-btn");if(!btn)return;var mode=btn.dataset.mode,title=btn.dataset.title||"Exam";if(typeof window.jspdf==="undefined"){ecMsg("PDF library loading…","info");setTimeout(function(){if(typeof window.jspdf!=="undefined")btn.click();else ecMsg("PDF failed to load. Please refresh.","error");},2000);return;}if(mode==="exam"){var qs=[];slides.forEach(function(sl){var q={question:sl.querySelector(".ec-qtext").innerHTML,options:{}};sl.querySelectorAll(".ec-opt").forEach(function(o){q.options[o.dataset.opt]=o.querySelector("span:nth-child(2)").innerHTML;});q.answer=sl.querySelector(".ec-opt").dataset.correct;var ex=sl.querySelector(".ec-expl");q.explanation=ex?ex.innerHTML:"";qs.push(q);});ecGenExamPDF(title,qs,true);}else if(mode==="result"&&resultData)ecGenResultPDF(title,resultData,resultData.details);});
function ecGetDoc(){try{return new window.jspdf.jsPDF({orientation:"portrait",unit:"mm",format:"a4"});}catch(er){ecMsg("PDF error: "+er.message,"error");return null;}}
function ecAddWatermarkAndFooter(doc){var pg=doc.internal.getNumberOfPages(),pw=doc.internal.pageSize.getWidth(),ph=doc.internal.pageSize.getHeight();for(var p=1;p<=pg;p++){doc.setPage(p);doc.saveGraphicsState();doc.setGState(new doc.GState({opacity:0.04}));doc.setFontSize(48);doc.setFont("helvetica","bold");doc.setTextColor(30,58,138);doc.text(EC_WM,pw/2,ph/2,{align:"center",angle:45});doc.restoreGraphicsState();doc.setFillColor(30,58,138);doc.rect(0,ph-11,pw,11,"F");doc.setFontSize(8);doc.setFont("helvetica","bold");doc.setTextColor(255,255,255);doc.text(EC_WM,pw/2,ph-4,{align:"center"});doc.setFont("helvetica","normal");doc.setTextColor(180,200,240);doc.text("Page "+p+" of "+pg,pw-EC_M,ph-4,{align:"right"});}}
function ecAddPage(doc,y,needed,ph){if(y+needed>ph-16){doc.addPage();return EC_M+4;}return y;}
function ecCard(doc,x,y,w,h,r,fill,border){if(fill)doc.setFillColor(fill[0],fill[1],fill[2]);if(border)doc.setDrawColor(border[0],border[1],border[2]);doc.roundedRect(x,y,w,h,r||3,r||3,fill&&border?"FD":(fill?"F":"S"));}
function ecBadge(doc,x,y,letter,color){doc.setFillColor(color[0],color[1],color[2]);doc.circle(x+3.5,y+3.5,3.5,"F");doc.setFontSize(7);doc.setFont("helvetica","bold");doc.setTextColor(255,255,255);doc.text(letter,x+3.5,y+5,{align:"center"});}
function ecGenExamPDF(title,qs,showAns){title=ecClean(title||"Exam");var doc=ecGetDoc();if(!doc)return;var pw=doc.internal.pageSize.getWidth(),ph=doc.internal.pageSize.getHeight(),M=EC_M,cw=pw-M*2,y=M;doc.setFillColor(30,58,138);doc.rect(0,0,pw,32,"F");doc.setFontSize(17);doc.setFont("helvetica","bold");doc.setTextColor(255,255,255);doc.text(title,M,16);doc.setFontSize(9);doc.setFont("helvetica","normal");doc.text(qs.length+" Questions | "+new Date().toLocaleDateString()+" | "+EC_WM,M,25);y=42;qs.forEach(function(q,i){var qT=ecClean(q.question),oT={};["A","B","C","D"].forEach(function(k){oT[k]=ecClean((q.options&&q.options[k])||"");});var eT=showAns&&q.explanation?ecClean(q.explanation):"";doc.setFontSize(11);doc.setFont("helvetica","bold");var ql=doc.splitTextToSize(qT,cw-18),cH=ql.length*5.5+8;["A","B","C","D"].forEach(function(k){var ol=doc.splitTextToSize(oT[k],cw-30);cH+=ol.length*5+6;});if(eT){var el=doc.splitTextToSize(eT,cw-30);cH+=el.length*4.5+12;}cH+=8;y=ecAddPage(doc,y,Math.min(cH,ph-40),ph);ecCard(doc,M,y-2,cw,cH,4,[248,250,252],[226,232,240]);doc.setFillColor(37,99,235);doc.roundedRect(M+4,y,10,7,2,2,"F");doc.setFontSize(8);doc.setFont("helvetica","bold");doc.setTextColor(255,255,255);doc.text("Q"+String(i+1),M+9,y+4.8,{align:"center"});doc.setTextColor(15,23,42);doc.setFontSize(11);doc.setFont("helvetica","bold");doc.text(ql,M+18,y+4);y+=ql.length*5.5+8;["A","B","C","D"].forEach(function(k){y=ecAddPage(doc,y,10,ph);var isA=showAns&&(q.answer||"").split(",").map(function(s){return s.trim();}).indexOf(k)>-1;ecBadge(doc,M+6,y-2,k,isA?[22,163,74]:[148,163,184]);var ol=doc.splitTextToSize(oT[k],cw-30);if(isA){doc.setFont("helvetica","bold");doc.setTextColor(22,101,52);}else{doc.setFont("helvetica","normal");doc.setTextColor(51,65,85);}doc.text(ol,M+18,y+2);y+=ol.length*5+6;});if(eT){y=ecAddPage(doc,y,12,ph);var el=doc.splitTextToSize(eT,cw-30);doc.setFillColor(255,251,235);doc.setDrawColor(245,158,11);doc.roundedRect(M+6,y-2,cw-12,el.length*4.5+8,2,2,"FD");doc.setFont("helvetica","italic");doc.setTextColor(120,70,0);doc.text(el,M+10,y+2.5);y+=el.length*4.5+12;}y+=8;});ecAddWatermarkAndFooter(doc);doc.save(String(title).replace(/[^a-z0-9]+/gi,"-").toLowerCase()+"-exam.pdf");}
function ecGenResultPDF(title,s,details){title=ecClean(title||"Exam");s=s||{};details=details||[];var doc=ecGetDoc();if(!doc)return;var pw=doc.internal.pageSize.getWidth(),ph=doc.internal.pageSize.getHeight(),M=EC_M,cw=pw-M*2,y=M;var hc=s.passed?[22,163,74]:[220,38,38];doc.setFillColor(hc[0],hc[1],hc[2]);doc.rect(0,0,pw,34,"F");doc.setFontSize(16);doc.setFont("helvetica","bold");doc.setTextColor(255,255,255);doc.text(title+" — Result",M,14);doc.setFontSize(10);doc.setFont("helvetica","normal");doc.text((s.passed?"PASSED":"FAILED")+" | "+new Date().toLocaleDateString()+" | "+EC_WM,M,24);y=44;var stats=[{label:"Score",value:s.score+"/"+s.total},{label:"Percentage",value:s.pct+"%"},{label:"Time",value:fmtL(s.time_taken||0)},{label:"Rank",value:"#"+(s.rank||"-")},{label:"Attempts",value:String(s.attempts||1)}],sw=cw/stats.length;ecCard(doc,M,y,cw,22,3,[248,250,252],[226,232,240]);stats.forEach(function(st,ix){var cx=M+ix*sw+sw/2;doc.setFontSize(7);doc.setFont("helvetica","normal");doc.setTextColor(148,163,184);doc.text(st.label,cx,y+7,{align:"center"});doc.setFontSize(11);doc.setFont("helvetica","bold");doc.setTextColor(15,23,42);doc.text(st.value,cx,y+16,{align:"center"});});y+=30;details.forEach(function(r,i){var qT=ecClean(r.question),oT={};["A","B","C","D"].forEach(function(k){oT[k]=ecClean((r.options&&r.options[k])||"");});var eT=r.explanation?ecClean(r.explanation):"";var ql=doc.splitTextToSize(qT,cw-18),cH=ql.length*5+10;["A","B","C","D"].forEach(function(k){var ol=doc.splitTextToSize(oT[k],cw-30);cH+=ol.length*4.5+5;});if(eT){var el=doc.splitTextToSize(eT,cw-30);cH+=el.length*4.5+12;}cH+=8;y=ecAddPage(doc,y,Math.min(cH,ph-40),ph);ecCard(doc,M,y-2,cw,cH,4,[248,250,252],[226,232,240]);var sc=r.correct?[22,163,74]:(!r.given?[148,163,184]:[220,38,38]);doc.setFillColor(sc[0],sc[1],sc[2]);doc.roundedRect(M+4,y,10,7,2,2,"F");doc.setFontSize(8);doc.setFont("helvetica","bold");doc.setTextColor(255,255,255);doc.text("Q"+String(i+1),M+9,y+4.8,{align:"center"});var ss=r.correct?"Correct":(!r.given?"Skipped":"Wrong");doc.setTextColor(sc[0],sc[1],sc[2]);doc.text(ss,M+18,y+4.8);y+=10;doc.setTextColor(15,23,42);doc.setFontSize(10);doc.setFont("helvetica","bold");doc.text(ql,M+6,y);y+=ql.length*5+5;["A","B","C","D"].forEach(function(k){y=ecAddPage(doc,y,10,ph);var ca=(r.answer||"").split(",").map(function(s){return s.trim();}),ga=(r.given||"").split(",").map(function(s){return s.trim();});var isA=ca.indexOf(k)>-1,isW=ga.indexOf(k)>-1&&!isA;var bc=isA?[22,163,74]:(isW?[220,38,38]:[148,163,184]);ecBadge(doc,M+6,y-2,k,bc);var ol=doc.splitTextToSize(oT[k],cw-30);if(isA){doc.setFont("helvetica","bold");doc.setTextColor(22,101,52);}else if(isW){doc.setFont("helvetica","bold");doc.setTextColor(185,28,28);}else{doc.setFont("helvetica","normal");doc.setTextColor(51,65,85);}doc.text(ol,M+18,y+2);y+=ol.length*4.5+5;});if(eT){y=ecAddPage(doc,y,12,ph);var el=doc.splitTextToSize(eT,cw-30);doc.setFillColor(255,251,235);doc.setDrawColor(245,158,11);doc.roundedRect(M+6,y-2,cw-12,el.length*4.5+8,2,2,"FD");doc.setFont("helvetica","italic");doc.setTextColor(120,70,0);doc.text(el,M+10,y+2.5);y+=el.length*4.5+12;}y+=8;});ecAddWatermarkAndFooter(doc);doc.save(String(title).replace(/[^a-z0-9]+/gi,"-").toLowerCase()+"-result.pdf");}
});
})();
';}